import { useMutation } from '@tanstack/react-query';
import axios, { AxiosError } from 'axios';
import { isPast } from 'date-fns';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AccountDangerZone,
  AccountPageSkeleton,
  AccountPrivacySettings,
  AccountSubscriptionSettings,
  AccountUser,
} from '../components';
import { toast } from '../hooks';
import { useAuthContext } from '../providers';
import { supabase } from '../supabaseClient';

export const AccountPage = () => {
  const { user, loadingUser } = useAuthContext();
  const [isDeletingLoading, setIsDeletingLoading] = useState(false);
  const [isResettingChatLoading, setIsResettingChatLoading] = useState(false);

  const navigate = useNavigate();

  const subscriptionEndDate = user?.subscription_end_date
    ? new Date(user.subscription_end_date).toLocaleDateString('us-EN', {
        dateStyle: 'medium',
      })
    : null;

  const isSubscriptionExpired = subscriptionEndDate
    ? isPast(subscriptionEndDate)
    : null;

  const resetChatHistory = async (password: string) => {
    const userId = user?.user_id;

    if (!userId) return;

    setIsResettingChatLoading(true);

    try {
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user.email ?? '',
        password,
      });

      if (signInError) {
        toast({
          title: 'incorrect password',
          description: 'please check your password and try again.',
          variant: 'destructive',
        });
        return;
      }

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        toast({
          title: 'error validating session',
          description: 'please try again or contact support.',
          variant: 'destructive',
        });
        return;
      }

      const response = await axios.delete(
        `${process.env.REACT_APP_API_URL}/user/chat-history`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      if (response.status === 200) {
        toast({
          title: 'all clear!',
          description: 'starting fresh with a clean slate.',
        });
      }
    } catch (error) {
      toast({
        title: 'something went wrong',
        description:
          'unable to clear chat history. please try again later or contact support.',
        variant: 'destructive',
      });
    } finally {
      setIsResettingChatLoading(false);
    }
  };

  const deleteUser = async (password?: string) => {
    if (!user) return;

    setIsDeletingLoading(true);

    try {
      if (user.app_metadata.provider === 'email') {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: user.email ?? '',
          password: password ?? '',
        });

        if (signInError) {
          toast({
            title: 'incorrect password',
            description: 'please check your password and try again.',
            variant: 'destructive',
          });
          return;
        }
      }

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        toast({
          title: 'error validating session',
          description: 'please try again or contact support.',
          variant: 'destructive',
        });
        return;
      }

      const response = await axios.delete(
        `${process.env.REACT_APP_API_URL}/user`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      if (response.status === 200) {
        await supabase.auth.signOut();

        toast({
          title: 'account deleted - we will miss you!',
          description: 'your account has been successfully deleted.',
        });

        navigate('/');
      }
    } catch (error) {
      if (axios.isAxiosError(error)) {
        toast({
          title: 'whoops!',
          description:
            error.response?.data?.message ||
            'unable to delete account. please try again or contact support.',
          variant: 'destructive',
        });
      }
    } finally {
      setIsDeletingLoading(false);
    }
  };

  const { mutate: handleCancelSubscription } = useMutation({
    mutationFn: () => {
      const userId = user?.user_id;
      return axios.post(
        `${process.env.REACT_APP_API_URL}/cancel-subscription`,
        {
          userId,
        }
      );
    },
    onError: (error) => {
      if (error instanceof AxiosError) {
        return toast({
          title: 'error!',
          description:
            'an error occurred while canceling subscription, try again or contact support.',
          variant: 'destructive',
        });
      }
    },
    onSuccess: () => {
      return toast({
        title: 'success! subscription canceled',
      });
    },
  });

  return (
    <div className='mt-6 w-full max-w-96 mx-auto overflow-x-hidden md:mx-auto md:max-w-[620px]'>
      {loadingUser ? (
        <AccountPageSkeleton />
      ) : (
        user && (
          <div className='grid gap-8'>
            <AccountUser user={user} />
            <div className='w-full h-[1px] bg-neutral-400'></div>
            <AccountPrivacySettings />
            <div className='w-full h-[1px] bg-neutral-400'></div>
            <AccountSubscriptionSettings
              onCancelSubscription={handleCancelSubscription}
              user={user}
              isSubscriptionExpired={!!isSubscriptionExpired}
              subscriptionEndDate={subscriptionEndDate}
            />
            <div className='w-full h-[1px] bg-neutral-400'></div>
            <AccountDangerZone
              user={user}
              onResetChatHistory={resetChatHistory}
              onDeleteUser={deleteUser}
              isDeletingLoading={isDeletingLoading}
              isResettingChatLoading={isResettingChatLoading}
            />
          </div>
        )
      )}
    </div>
  );
};
