import { en, I18nVariables, merge } from '@supabase/auth-ui-shared';

import { Link, useSearchParams } from 'react-router-dom';
import { AuthForm, CalmiLogo } from '../components';
import { EmailAuthProps, SocialAuth } from '../components/auth/interfaces';
import {
  AUTH_CONFIG,
  AUTH_QUERY_PARAM_SIGN_IN,
  AUTH_VIEW_QUERY_PARAM,
} from '../constants';
import { useAuthState } from '../hooks/use-auth-state';
import { supabase } from '../supabaseClient';

export const AuthPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const view =
    searchParams.get(AUTH_VIEW_QUERY_PARAM) ?? AUTH_QUERY_PARAM_SIGN_IN;
  const i18n: I18nVariables = merge(
    en,
    AUTH_CONFIG.localization.variables ?? {}
  );

  const {
    authView,
    setAuthView,
    defaultEmail,
    setDefaultEmail,
    defaultPassword,
    setDefaultPassword,
  } = useAuthState(view);

  const emailProp: Omit<EmailAuthProps, 'authView' | 'id'> = {
    supabaseClient: supabase,
    setAuthView,
    defaultEmail,
    defaultPassword,
    setDefaultEmail,
    setDefaultPassword,
    i18n,
  };

  return (
    <div className='lowercase px-4 py-4 sm:px-8 sm:pt-6 md:px-12 md:pt-8 lg:px-16 lg:pt-10 xl:px-20 max-w-7xl mx-auto'>
      <header>
        <CalmiLogo />
      </header>

      <div className='mt-8 mx-auto max-w-[440px] sm:mt-20 sm:max-w-[360px]'>
        <div className='grid gap-6'>
          <div className='text-center'>
            <h1 className='text-xl font-semibold md:text-2xl'>
              ready when you are
            </h1>
            <p className='text-zinc-700 md:text-lg'>
              your safe space, one convo at a time
            </p>
          </div>

          <div className='mt-2 md:mt-4'>
            <AuthForm authView={authView} emailProp={emailProp} />
          </div>

          <div className='flex items-center gap-4'>
            <div className='w-full h-[1px] bg-zinc-300' />
            <p className='text-zinc-700'>or</p>
            <div className='w-full h-[1px] bg-zinc-300' />
          </div>

          <SocialAuth
            supabaseClient={supabase}
            providers={AUTH_CONFIG.providers}
            socialLayout={AUTH_CONFIG.socialLayout}
            redirectTo={AUTH_CONFIG.redirectTo}
            i18n={i18n}
          />

          <p className='mt-4 text-center text-balance text-xs leading-tight text-primary/80'>
            by signing up, you agree to our{' '}
            <Link to='/terms-of-service' target='_blank' className='underline'>
              terms of service
            </Link>
            ,{' '}
            <Link to='/privacy-policy' target='_blank' className='underline'>
              privacy policy
            </Link>{' '}
            and acknowledge our{' '}
            <Link to='/ai-disclaimer' target='_blank'>
              <span className='underline'>ai disclaimer</span>
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};
