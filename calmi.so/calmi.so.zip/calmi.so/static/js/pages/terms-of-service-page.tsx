import { Link } from 'react-router-dom';
import { CalmiLogo } from '../components';

export const TermsOfServicePage = () => {
  return (
    <div className='px-4 pt-4 sm:px-8 sm:pt-6 md:px-12 md:pt-8 lg:px-16 lg:pt-10 xl:px-20 max-w-7xl mx-auto'>
      <header>
        <CalmiLogo />
      </header>
      <div className='px-4 sm:px-8 md:px-12 lg:px-24 my-8 sm:mb-20 max-w-[768px] mx-auto'>
        <h1 className='text-2xl font-bold'>Terms of Service</h1>
        <p className='font-semibold'>Last Updated: December 21, 2023</p>

        <div className='grid gap-8 mt-8'>
          <div className='grid gap-4'>
            <h2 className='text-xl font-semibold'>
              1. Emergency Situations and Crisis Disclaimer
            </h2>
            <div>
              <p>
                <strong>PLEASE READ THIS SECTION CAREFULLY</strong>
              </p>
              <p className='mt-2'>
                IF YOU ARE EXPERIENCING THOUGHTS OF SUICIDE, SELF-HARM, OR
                HARMING OTHERS, OR IF YOU ARE EXPERIENCING A MENTAL HEALTH
                EMERGENCY:
              </p>
              <ul className='list-disc list-inside'>
                <li>IMMEDIATELY STOP USING CALMI</li>
                <li>DIAL 988 (US) FOR THE SUICIDE AND CRISIS LIFELINE</li>
                <li>CALL YOUR LOCAL EMERGENCY SERVICES (911 IN US)</li>
                <li>GO TO THE NEAREST EMERGENCY ROOM</li>
                <li>CONTACT A QUALIFIED MENTAL HEALTH PROFESSIONAL</li>
              </ul>
              <p>
                CALMI IS NOT AN EMERGENCY SERVICE AND CANNOT HELP IN CRISIS
                SITUATIONS.
              </p>
            </div>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>2. Introduction</h2>
            <p>
              Welcome to Calmi Inc. (<a href='https://calmi.so'>calmi.so</a>), an
              AI-powered mental health application incorporated as Calmi Inc., a
              Delaware C Corporation (hereinafter referred to as "calmi"). By accessing 
              or using our app, you agree to these Terms of Service ("Terms"). If you 
              disagree with any part of these Terms, please do not use our services.
            </p>
          </div>

          <div className='grid gap-2'>
            <h2 className='text-xl font-semibold'>
              3. Age Restrictions and Eligibility
            </h2>

            <div>
              <h3 className='text-lg font-semibold'>
                3.1 Minimum Age Requirements
              </h3>
              <ul className='list-disc list-inside'>
                <li>You must be at least 13 years old to use calmi</li>
                <li>
                  If you are between 13 and 18 years old, you must:
                  <ul className='list-disc list-inside'>
                    <li>
                      Have your parent or legal guardian's permission to use
                      calmi
                    </li>
                    <li>
                      Have your parent or legal guardian review and accept these
                      Terms on your behalf
                    </li>
                    <li>Use calmi under adult supervision</li>
                  </ul>
                </li>
              </ul>
            </div>

            <div>
              <h3 className='text-lg font-semibold'>3.2 User Responsibility</h3>
              <p>By using calmi, you represent and warrant that:</p>
              <ul className='list-disc list-inside'>
                <li>You are at least 13 years old</li>
                <li>
                  If you are between 13 and 18 years old, you have obtained
                  parental or legal guardian permission
                </li>
                <li>
                  You have provided truthful and accurate information about your
                  age
                </li>
                <li>
                  You understand that calmi reserves the right to terminate any
                  account at any time if we believe you have misrepresented your
                  age
                </li>
              </ul>
            </div>

            <div>
              <h3 className='text-lg font-semibold'>
                3.3 Parent/Guardian Responsibility
              </h3>
              <p>
                For users between 13 and 18 years old, the parent or legal
                guardian:
              </p>
              <ul className='list-disc list-inside'>
                <li>
                  Must review these Terms and our{' '}
                  <Link to='/privacy-policy' className='underline'>
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  Accepts responsibility for:
                  <ul className='list-disc list-inside'>
                    <li>The minor's compliance with these Terms</li>
                    <li>All activities that occur under the minor's account</li>
                    <li>Any payments or charges associated with the account</li>
                    <li>
                      Ensuring appropriate professional mental health care is
                      sought when needed
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>4. User Accounts</h2>
            <ul className='list-disc list-inside'>
              <li>
                You must provide a valid email address to create an account
              </li>
              <li>
                You may be required to provide additional personal information
              </li>
              <li>
                You are responsible for maintaining the confidentiality of your
                account credentials
              </li>
              <li>You are responsible for all activities under your account</li>
              <li>
                You must immediately notify us of any unauthorized use of your
                account
              </li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>
              5. Subscriptions and Payment
            </h2>
            <ul className='list-disc list-inside'>
              <li>calmi offers three free AI therapy sessions</li>
              <li>Continued use requires a subscription</li>
              <li>
                Payments are processed through Stripe, subject to Stripe's Terms
                of Service and Privacy Policy
              </li>
              <li>
                We offer pro-rated refunds within the first 14 days of a new
                subscription
              </li>
              <li>Subscription fees are billed in advance</li>
              <li>
                You authorize us to charge your payment method for all fees
              </li>
              <li>Prices may change with 30 days notice</li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>
              6. Mandatory Acknowledgments
            </h2>
            <p>By using calmi, you explicitly acknowledge and agree that:</p>
            <p>a) calmi is NOT:</p>
            <ul className='list-disc list-inside'>
              <li>A substitute for professional mental health treatment</li>
              <li>A crisis intervention service</li>
              <li>A suicide prevention service</li>
              <li>
                Capable of preventing or treating mental health emergencies
              </li>
              <li>Staffed by human mental health professionals</li>
              <li>A medical device or medical service of any kind</li>
              <li>
                Capable of diagnosing or treating any medical or mental health
                condition
              </li>
            </ul>
            <p>b) You understand that:</p>
            <ul className='list-disc list-inside'>
              <li>
                calmi uses artificial intelligence technology that has inherent
                limitations
              </li>
              <li>
                The AI may provide incorrect, inappropriate, or harmful
                responses
              </li>
              <li>You use calmi entirely at your own risk</li>
              <li>No specific outcomes or benefits are guaranteed</li>
              <li>
                You are solely responsible for all decisions and actions taken
                based on interactions with calmi
              </li>
              <li>
                calmi cannot and does not monitor for user safety or well-being
              </li>
              <li>
                No human reviews or monitors your conversations in real-time
              </li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>
              7. Liability Waiver and Release
            </h2>
            <p>To the maximum extent permitted by law, you:</p>
            <p>
              a) EXPRESSLY WAIVE AND RELEASE calmi, its owners, employees,
              contractors, partners, and affiliates from any and all liability,
              claims, causes of action, damages, costs, or expenses arising
              from:
            </p>
            <ul className='list-disc list-inside'>
              <li>Your use of the service</li>
              <li>
                Any decisions or actions you take based on interactions with the
                AI
              </li>
              <li>
                Any harm, injury, or damages (including death) related to using
                or following advice from calmi
              </li>
              <li>
                Failure to seek appropriate professional medical or mental
                health care
              </li>
              <li>
                Any emergency situations or crises where calmi was used instead
                of appropriate emergency services
              </li>
            </ul>
            <p>
              b) AGREE TO INDEMNIFY AND HOLD HARMLESS calmi and its affiliates
              against any claims, damages, or expenses (including legal fees)
              arising from:
            </p>
            <ul className='list-disc list-inside'>
              <li>Your violation of these terms</li>
              <li>Your use of the service</li>
              <li>
                Any harm to yourself or others related to your use of calmi
              </li>
            </ul>
          </div>

          <div className='grid gap-2'>
            <h2 className='text-xl font-semibold'>
              8. Privacy and Data Protection
            </h2>
            <div>
              <h3 className='text-lg font-semibold'>
                8.1 Data Collection and Storage
              </h3>
              <ul className='list-disc list-inside'>
                <li>
                  All conversations are encrypted end-to-end using
                  industry-standard encryption
                </li>
                <li>
                  Data is stored securely in Supabase, a PostgreSQL database
                  platform with built-in encryption
                </li>
                <li>
                  Supabase implements row-level security (RLS) policies to
                  ensure data isolation
                </li>
                <li>Database backups are encrypted and stored securely</li>
                <li>
                  All data transmissions between our application and Supabase
                  are encrypted using TLS 1.3
                </li>
                <li>
                  Authentication tokens and sensitive credentials are never
                  stored in client-side storage
                </li>
              </ul>
            </div>

            <div>
              <h3 className='text-lg font-semibold'>
                8.2 Use of Conversation Data
              </h3>
              <p>You grant calmi permission to:</p>
              <ul className='list-disc list-inside'>
                <li>
                  Store and process your conversation data within Supabase
                </li>
                <li>Use anonymized data for service improvement</li>
                <li>Share anonymized data with research partners</li>
                <li>Analyze conversations for quality assurance</li>
                <li>Create and maintain database backups</li>
              </ul>
            </div>

            <div>
              <h3 className='text-lg font-semibold'>
                8.3 Data Access and Deletion
              </h3>
              <ul className='list-disc list-inside'>
                <li>You may request your data at any time</li>
                <li>Data deletion requests will be honored within 30 days</li>
                <li>
                  Deletion requests will be executed across all systems and
                  backups
                </li>
                <li>Some data may be retained if required by law</li>
                <li>
                  We may deny deletion requests in cases of abuse or legal
                  obligations
                </li>
                <li>
                  For full details, please refer to our{' '}
                  <a href='/privacy-policy' className='underline'>
                    Privacy Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>9. Communication</h2>
            <ul className='list-disc list-inside'>
              <li>
                By signing up, you consent to receive emails from calmi
                regarding:
                <ul className='list-disc list-inside'>
                  <li>Service updates</li>
                  <li>Feedback requests</li>
                  <li>Promotional content</li>
                </ul>
              </li>
              <li>
                You may opt out of promotional emails via instructions in the
                email
              </li>
              <li>
                Service-related emails cannot be opted out of while you maintain
                an account
              </li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>10. Intellectual Property</h2>
            <ul className='list-disc list-inside'>
              <li>
                calmi retains all rights to the app's content, features, and
                functionality
              </li>
              <li>
                Users retain ownership of their original content input during
                interactions
              </li>
              <li>
                Users grant calmi a non-exclusive, worldwide license to use
                their content for:
                <ul className='list-disc list-inside'>
                  <li>Service improvement</li>
                  <li>Research and development</li>
                  <li>Quality assurance</li>
                  <li>Marketing (with additional consent)</li>
                </ul>
              </li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>11. Prohibited Uses</h2>
            <p>You agree not to:</p>
            <ul className='list-disc list-inside'>
              <li>Use the app for any illegal purpose</li>
              <li>Attempt to gain unauthorized access</li>
              <li>Use the app to harass, abuse, or harm others</li>
              <li>Impersonate any person or entity</li>
              <li>Interfere with or disrupt functionality</li>
              <li>Attempt to reverse engineer the service</li>
              <li>Create competing services using our data</li>
              <li>Automate or scrape content</li>
              <li>Share account credentials</li>
            </ul>
          </div>

          <div className='grid gap-2'>
            <h2 className='text-xl font-semibold'>
              12. Service Limitations and Modifications
            </h2>

            <div>
              <h3 className='text-lg font-semibold'>
                12.1 Technical Limitations
              </h3>
              <ul className='list-disc list-inside'>
                <li>The AI may provide incorrect or inappropriate responses</li>
                <li>Service availability is not guaranteed</li>
                <li>Performance may vary based on technical factors</li>
                <li>Features may change without notice</li>
              </ul>
            </div>

            <div>
              <h3 className='text-lg font-semibold'>
                12.2 Content Limitations
              </h3>
              <ul className='list-disc list-inside'>
                <li>The AI cannot provide medical advice</li>
                <li>Responses are generated by algorithms, not humans</li>
                <li>Content may be inappropriate or triggering</li>
                <li>No guarantee of accuracy or appropriateness</li>
              </ul>
            </div>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>13. Termination</h2>
            <p>We may terminate or suspend your access:</p>
            <ul className='list-disc list-inside'>
              <li>Without prior notice or liability</li>
              <li>For any reason in our sole discretion</li>
              <li>If we believe you violated these terms</li>
              <li>To comply with law or protect our rights</li>
              <li>For account inactivity</li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>14. Accessibility</h2>
            <ul className='list-disc list-inside'>
              <li>We strive to make our services accessible to all users</li>
              <li>Contact our support team for accessibility assistance</li>
              <li>We welcome feedback on improving accessibility</li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>15. Third-party Links</h2>
            <ul className='list-disc list-inside'>
              <li>We may provide links to external resources</li>
              <li>We are not responsible for third-party content</li>
              <li>Third-party services have their own terms</li>
              <li>Use third-party services at your own risk</li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>16. Updates to Terms</h2>
            <ul className='list-disc list-inside'>
              <li>We may modify these terms at any time</li>
              <li>Changes are effective immediately upon posting</li>
              <li>Continued use constitutes acceptance of changes</li>
              <li>Material changes will be notified via email</li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>17. Contact Information</h2>
            <p>
              Corporate Address:
              <br />
              calmi Inc.
              <br />
              1111b S Governors Avenue, STE 23924
              <br />
              Dover, DE, 19904, US
            </p>
            <p className='mt-4'>Legal Representative: Deniz Han Aydin</p>
            <p className='mt-4'>
              For privacy-related inquiries:
              <br />
              Email: <a href='mailto:dennis@calmi.so'>dennis@calmi.so</a>
              <br />
              Website: <a href='https://calmi.so'>calmi.so</a>
            </p>
          </div>

          <p>
            By using calmi Inc., you confirm that you have read, understood, and
            agree to these terms and conditions.
          </p>
        </div>
      </div>
    </div>
  );
};
