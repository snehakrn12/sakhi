import { Link } from 'react-router-dom';
import { CalmiLogo } from '../components';

export const PrivacyPolicyPage = () => {
  return (
    <div className='px-4 pt-4 sm:px-8 sm:pt-6 md:px-12 md:pt-8 lg:px-16 lg:pt-10 xl:px-20 max-w-7xl mx-auto'>
      <header>
        <CalmiLogo />
      </header>
      <div className='px-4 sm:px-8 md:px-12 lg:px-24 my-8 sm:mb-20 max-w-[768px] mx-auto'>
        <h1 className='text-2xl font-bold'>Privacy Policy</h1>
        <p>Last Updated: December 21, 2023</p>

        <div className='grid gap-8 mt-8'>
          <div className='grid gap-4'>
            <h2 className='text-xl font-semibold'>
              1. Emergency Situations and Crisis Disclaimer
            </h2>
            <div>
              <p>
                <strong>PLEASE READ THIS SECTION CAREFULLY</strong>
              </p>
              <p className='mt-2'>
                IF YOU ARE EXPERIENCING THOUGHTS OF SUICIDE, SELF-HARM, OR
                HARMING OTHERS, OR IF YOU ARE EXPERIENCING A MENTAL HEALTH
                EMERGENCY:
              </p>
              <ul>
                <li>IMMEDIATELY STOP USING CALMI INC.</li>
                <li>DIAL 988 (US) FOR THE SUICIDE AND CRISIS LIFELINE</li>
                <li>CALL YOUR LOCAL EMERGENCY SERVICES (911 IN US)</li>
                <li>GO TO THE NEAREST EMERGENCY ROOM</li>
                <li>CONTACT A QUALIFIED MENTAL HEALTH PROFESSIONAL</li>
              </ul>
              <p>
                CALMI INC. IS NOT AN EMERGENCY SERVICE AND CANNOT HELP IN CRISIS
                SITUATIONS.
              </p>
            </div>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>2. Introduction</h2>
            <p>
              Welcome to Calmi Inc. (
              <Link className='underline' to='https://calmi.so'>
                calmi.so
              </Link>
              ), an AI-powered mental health application, incorporated as Calmi
              Inc., a Delaware C Corporation (hereinafter referred to as
              "calmi"). By accessing or using our app, you agree to these Terms
              of Service ("Terms"). If you disagree with any part of these
              Terms, please do not use our services.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>
              3. Eligibility and Age Restrictions
            </h2>
            <p>
              You must be at least 18 years old to use calmi If you are between
              13 and 18 years old, you may only use calmi with the consent and
              supervision of a parent or legal guardian. We do not knowingly
              collect or solicit personal information from individuals under 13.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>4. User Accounts</h2>
            <p>
              To create an account, you must provide a valid email address and
              may be required to provide additional personal information. You
              are responsible for maintaining the confidentiality of your
              account credentials and for all activities under your account.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>
              5. Subscriptions and Payment
            </h2>
            <p>
              calmi offers three free AI therapy sessions. Continued use
              requires a subscription. Payments are processed through Stripe,
              subject to Stripe's Terms of Service and Privacy Policy. Our
              refund policy allows for pro-rated refunds within the first 14
              days of a new subscription.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>
              6. AI Therapy and Liability Disclaimer
            </h2>
            <p>
              calmi provides general mental health advice through AI technology.
              However:
            </p>
            <ul>
              <li>
                calmi is not a licensed therapist or mental health provider.
              </li>
              <li>
                The AI is not a substitute for professional medical advice,
                diagnosis, or treatment.
              </li>
              <li>
                calmi does not guarantee the accuracy, completeness, or
                appropriateness of the AI's advice.
              </li>
              <li>
                You acknowledge that calmi is not responsible for any
                consequences, harm, or losses resulting from using the AI's
                advice.
              </li>
              <li>
                calmi is not suitable for emergency situations or crisis
                intervention.
              </li>
            </ul>
            <p>
              If you are experiencing a mental health emergency, please contact
              your local emergency services immediately or use a crisis
              helpline.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>
              7. Privacy and Data Protection
            </h2>
            <p>We prioritize the protection of your sensitive information:</p>
            <ul>
              <li>All conversations are encrypted end-to-end.</li>
              <li>
                We do not share your personal data or conversation logs with
                third parties, except as required by law.
              </li>
              <li>
                Data is stored securely and in compliance with applicable data
                protection regulations.
              </li>
            </ul>
            <p>For full details, please refer to our Privacy Policy.</p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>8. Communication</h2>
            <p>
              By signing up, you consent to receive emails from calmi regarding
              service updates, feedback requests, and promotional content. You
              may opt out of promotional emails by following the instructions in
              the email.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>9. Data Deletion</h2>
            <p>
              You may request the deletion of your account and associated data
              at any time by contacting our support team. We will comply with
              your request within 30 days, subject to legal retention
              requirements.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>10. Intellectual Property</h2>
            <p>
              calmi retains all rights to the app's content, features, and
              functionality. Users retain ownership of any original content they
              input during interactions, granting calmi a non-exclusive license
              to use this content for service improvement.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>11. Prohibited Uses</h2>
            <p>You agree not to:</p>
            <ul>
              <li>Use the app for any illegal purpose</li>
              <li>
                Attempt to gain unauthorized access to any part of the app
              </li>
              <li>Use the app to harass, abuse, or harm others</li>
              <li>Impersonate any person or entity</li>
              <li>Interfere with or disrupt the app's functionality</li>
            </ul>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>12. Termination</h2>
            <p>
              calmi reserves the right to suspend or terminate your account for
              violations of these Terms or for any other reason at our
              discretion.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>
              13. Modifications to Terms
            </h2>
            <p>
              We may modify these Terms at any time. Continued use of the app
              after changes constitutes acceptance of the new terms. We will
              notify users of significant changes via email.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>14. Accessibility</h2>
            <p>
              calmi strives to make its services accessible to all users. If you
              have specific accessibility needs, please contact our support
              team.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>15. Third-party Links</h2>
            <p>
              calmi may provide links to external resources. We are not
              responsible for the content or practices of these third-party
              sites.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>16. Limitations of AI</h2>
            <p>
              While our AI strives to provide helpful advice, it has limitations
              in understanding complex human emotions and situations. It should
              not be considered a replacement for human judgment or professional
              mental health care.
            </p>
          </div>

          <div className='grid gap-1'>
            <h2 className='text-xl font-semibold'>16. Contact Information</h2>
            <p>
              If you have any questions about these Terms, please contact us at:
              <br />
              calmi <br />
              1111b S Governors Avenue, STE 23924 <br />
              Dover, DE, 19904, US <br />
              Legal Representative: Deniz Han Aydin <br />
              <a href='mailto:dennis@calmi.so'>dennis@calmi.so</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
