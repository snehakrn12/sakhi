import { useSearchParams } from 'react-router-dom';
import { ProfileHistory, ProfileOverview } from '../components';
import {
  PROFILE_ROUTE_HISTORY_QUERY_PARAM,
  PROFILE_TAB_QUERY_PARAM,
} from '../constants';
import { useAuthContext } from '../providers';

export const ProfilePage = () => {
  const { isSubscribed } = useAuthContext();

  const [searchParams] = useSearchParams();
  const isHistory =
    searchParams.get(PROFILE_TAB_QUERY_PARAM) ===
    PROFILE_ROUTE_HISTORY_QUERY_PARAM;

  return (
    <div className='w-full max-w-96 mx-auto md:max-w-[620px]'>
      {isHistory ? (
        <ProfileHistory isSubscribed={isSubscribed} />
      ) : (
        <ProfileOverview />
      )}
    </div>
  );
};
