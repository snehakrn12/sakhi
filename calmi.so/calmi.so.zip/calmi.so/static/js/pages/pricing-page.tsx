import { Sparkle, Sparkles } from 'lucide-react';
import { CalmiLogo, FAQ, PricingCard, Testimonials } from '../components';
import { AudioPlayer } from '../components/audio-player';
import { PLAN } from '../constants';
import { useAuthContext } from '../providers';

const FAQ_ITEMS = [
  {
    headline: 'what is included in the plus plan?',
    description:
      "the plus plan offers unlimited therapy sessions, access to temporary chats, priority customer support, and early access to new features. it's perfect for those who want continuous support.",
  },
  {
    headline: 'can I cancel my subscription?',
    description:
      'yes, you can cancel anytime without fees. just go to settings, select "account," and manage your subscription. you\'ll retain access to paid features until the end of your billing period.',
  },
  {
    headline: 'is calmi a replacement for traditional therapy?',
    description:
      "calmi provides emotional support and complements traditional therapy, but it's not a replacement for professional care, especially for severe mental health conditions.",
  },
  {
    headline: 'what payment methods do you accept?',
    description:
      'we accept most major credit and debit cards through a secure payment processor for easy transactions.',
  },
  {
    headline: 'is my data secure and confidential?',
    description:
      'yes. we store session data securely in supabase using a vector database, which helps make the ai smarter and more responsive. all data is encrypted and managed in accordance with gdpr, a global privacy standard. if you request deletion, your data will be permanently removed from our system.',
  },
  {
    headline: 'does calmi support multiple languages?',
    description:
      "currently, calmi is available in english, but we're working on adding more languages to make mental health support accessible to everyone.",
  },
];

export const PricingPage = () => {
  const { user } = useAuthContext();

  return (
    <div className='px-4 pt-4 sm:px-8 sm:pt-6 md:px-12 md:pt-8 lg:px-16 lg:pt-10 xl:px-20 max-w-7xl mx-auto'>
      <header>
        <CalmiLogo />
      </header>
      <h1 className='text-4xl font-semibold text-center mt-8 mb-2 font-sans'>
        upgrade your plan
      </h1>
      <h2 className='text-lg font-medium text-center mb-8 font-sans'>
        unlimited access. cancel anytime
      </h2>
      <div className='grid'>
        <div className='grid grid-cols-[48px,1fr] items-center gap-2 mx-auto pr-4'>
          <AudioPlayer showProgressBar={false} src='/audio/calmi-sample.mp3' />
          <p className='inline-flex items-center gap-2'>
            <span>play me.</span>
          </p>
        </div>

        <div className='grid gap-4 max-w-[440px] mx-auto mt-6 md:max-w-none md:grid-cols-2'>
          <PricingCard
            title='plus'
            icon={<Sparkle fill='black' width={16} />}
            description='all the yapping you need, but on a student budget.'
            price='12'
            buttonText='upgrade to plus'
            buttonVariant='outline'
            planLink={PLAN.plus.link}
            perkList={[
              <p>
                <span className='font-bold'>8</span> therapy sessions/month
              </p>,
              <p>
                <span className='font-bold'>20min</span> session duration
              </p>,
              'super empathetic ai voice model',
              'extended session history',
              'sneak peek at beta features',
            ]}
            userEmail={user?.email ?? null}
          />

          <PricingCard
            title='pro'
            icon={<Sparkles fill='black' width={16} />}
            description='for when you’ve got a lot more on your mind.'
            planLink={PLAN.pro.link}
            buttonVariant='primary'
            buttonText='upgrade to pro'
            price='20'
            perkList={[
              'all in plus, plus...',
              <p>
                <span className='font-bold'>20</span> therapy sessions/month
              </p>,
              <p>
                <span className='font-bold'>30min</span> session duration
              </p>,
              'direct support, straight from dennis and vlady',
            ]}
            userEmail={user?.email ?? null}
          />
        </div>
      </div>

      <div className='mt-16 text-center'>
        <h2 className='text-4xl font-semibold mb-2'>
          trusted around the world
        </h2>
        <p className='text-lg mb-8'>
          50,000+ people are finding their calm with calmi
        </p>
        <div className='grid gap-4 px-4 sm:px-0'>
          <Testimonials />
        </div>
      </div>

      <div className='mt-24 text-center mb-24'>
        <h2 className='text-4xl font-semibold mb-8'>
          frequently asked questions
        </h2>
        <FAQ faqItems={FAQ_ITEMS} />
      </div>
    </div>
  );
};
