import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import App from './App';
import { Footer, Toaster } from './components';
import './globals.css';
import Layout from './layout';
import { AccountPage } from './pages/account-page';
import { AiDisclaimerPage } from './pages/ai-disclaimer-page';
import { AuthPage } from './pages/auth-page';
import { PricingPage } from './pages/pricing-page';
import { PrivacyPolicyPage } from './pages/privacy-policy-page';
import { ProfilePage } from './pages/profile-page';
import { TermsOfServicePage } from './pages/terms-of-service-page';
import { AuthProvider } from './providers';
import reportWebVitals from './reportWebVitals';

const queryClient = new QueryClient();

const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        index: true,
        element: <App />,
      },
      {
        path: 'auth' || 'auth/reset-password' || 'reset-password',
        element: <AuthPage />,
      },
      {
        path: 'pricing',
        element: (
          <>
            <PricingPage />
            <Footer />
          </>
        ),
      },
      {
        path: 'account',
        element: <AccountPage />,
      },
      {
        path: 'privacy-policy',
        element: (
          <>
            <PrivacyPolicyPage />
            <Footer />
          </>
        ),
      },
      {
        path: 'terms-of-service',
        element: (
          <>
            <TermsOfServicePage />
            <Footer />
          </>
        ),
      },
      {
        path: 'ai-disclaimer',
        element: (
          <>
            <AiDisclaimerPage />
            <Footer />
          </>
        ),
      },
      {
        path: 'profile',
        element: <ProfilePage />,
      },
    ],
  },
]);

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <RouterProvider router={router} />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
