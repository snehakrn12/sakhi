import { Loader2 } from 'lucide-react';
import { useState } from 'react';
import { SessionModeSwitch } from './components';
import { Footer } from './components/footer';
import Home from './components/home';
import Session from './components/session';
import { useAuthContext } from './providers';
import { supabase } from './supabaseClient';

type LoadingStateProps = {
  message?: string;
};

const LoadingState = ({
  message = 'setting up calmi...',
}: LoadingStateProps) => (
  <div className='absolute inset-0 flex justify-center items-center gap-2 bg-white'>
    <Loader2 className='h-4 w-4 animate-spin' />
    <p>{message}</p>
  </div>
);

function App() {
  const [isGenZMode, setIsGenZMode] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const {
    user,
    session,
    loadingUser,
    isSubscribed,
    sessionCountLimitReached,
    refreshUser,
  } = useAuthContext();

  const handleSessionCount = async () => {
    if (!user?.user_id) return;

    const { error: updateError } = await supabase
      .from('users')
      .update({
        session_count: user.session_count + 1,
      })
      .eq('user_id', user.user_id);

    if (!updateError) {
      refreshUser();
    }
  };

  const handleIsRecording = (isRecordingSession: boolean) => {
    setIsRecording(isRecordingSession);
    return isRecording;
  };

  if (loadingUser && !user) {
    return <LoadingState />;
  }

  if (!session && !user) {
    return (
      <>
        <Home />
        <Footer />
      </>
    );
  }

  if (session && user) {
    return (
      <>
        <div className='absolute top-5 right-5 z-[1]'>
          <SessionModeSwitch
            disabled={isRecording}
            isGenZMode={isGenZMode}
            setIsGenZMode={setIsGenZMode}
          />
        </div>
        <div className='mt-16'>
          <Session
            isSubscribed={isSubscribed}
            isGenZMode={isGenZMode}
            userId={user.user_id}
            sessionCountLimitReached={sessionCountLimitReached}
            handleSessionCount={handleSessionCount}
            handleIsRecording={handleIsRecording}
            session={session}
            subscriptionPlan={user.subscription_plan ?? null} // Add this line
          />
        </div>
      </>
    );
  }

  return <LoadingState />;
}

export default App;
