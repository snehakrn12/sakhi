'use client';
import posthog from 'posthog-js';
import { PostHogProvider } from 'posthog-js/react';
import { ReactNode } from 'react';
import { CookieConsentDialog } from '../components';
import { useAnalyticsConsent } from '../hooks';

interface PHProviderProps {
  children: ReactNode;
}

export function PHProvider({ children }: PHProviderProps) {
  const { updateAnalyticsConsent } = useAnalyticsConsent();

  return (
    <PostHogProvider client={posthog}>
      {children}
      <CookieConsentDialog
        companyName='calmi inc.'
        onAccept={() => updateAnalyticsConsent(true)}
        onDecline={() => updateAnalyticsConsent(false)}
        privacyPolicyUrl='/privacy-policy'
      />
    </PostHogProvider>
  );
}
