import { createContext, useContext, useEffect } from 'react';
import { useAuth } from '../hooks';
import { setAuthToken } from '../queries';

const AuthContext = createContext<ReturnType<typeof useAuth> | undefined>(
  undefined
);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const auth = useAuth();

  return <AuthContext.Provider value={auth}>{children}</AuthContext.Provider>;
};

export const useAuthContext = () => {
  const context = useContext(AuthContext);

  useEffect(() => {
    if (!context?.session) return;

    setAuthToken(context?.session);
  }, [context]);

  if (!context) {
    throw new Error('useAuthContext must be used within an AuthProvider');
  }
  return context;
};
