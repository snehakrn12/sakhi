import { useEffect, useRef, useState } from 'react';
import { SERVER_WS_URL } from '../constants';
import { useAuthContext } from '../providers';
import { supabase } from '../supabaseClient';
import { Session } from '../types';
import {
  generateSessionSummary,
  generateTherapyProfile,
  saveMessageToMessageHistory,
} from '../utils';

export const useSessionSummary = (userId: string | null) => {
  const { session } = useAuthContext();
  const [sessionId, setSessionId] = useState<string | null>(null);

  const sessionIdRef = useRef<string | null>(null);
  const lastActivityRef = useRef<Date>(new Date());
  const ws = useRef<WebSocket | null>(null);

  const resetLastActivity = () => {
    lastActivityRef.current = new Date();
  };

  useEffect(() => {
    // Check session health every minute
    const intervalId = setInterval(checkSessionHealth, 60000);

    return () => {
      clearInterval(intervalId);
    };
  }, [userId]);

  const initializeSessionData = (session: Session) => {
    setSessionId(session.id);
    sessionIdRef.current = session.id;
    initializeWebSocket(session.id);
  };

  const startSession = async () => {
    if (!userId) return;

    // Get all session with status "in_progress"
    const { data: sessionsInProgress } = await supabase
      .from('sessions')
      .select()
      .eq('user_id', userId)
      .eq('status', 'in_progress')
      .order('started_at', { ascending: false });

    // If no "in_progress" session insert a new one
    if (!sessionsInProgress || sessionsInProgress.length === 0) {
      const { data: session, error } = await supabase
        .from('sessions')
        .insert({ user_id: userId, status: 'in_progress' })
        .select()
        .single();

      if (error) {
        return null;
      } else {
        initializeSessionData(session);
        return session.id;
      }
    }

    // If multiple "in_progress" sessions exist, set all except the latest to "completed"
    if (sessionsInProgress.length > 1) {
      const [latestSession, ...oldSessions] = sessionsInProgress;
      const oldSessionIds = oldSessions.map((session) => session.id);

      await supabase
        .from('sessions')
        .update({ status: 'completed', ended_at: new Date().toISOString() })
        .in('id', oldSessionIds);

      // Set the latest "in_progress" session as current
      initializeSessionData(latestSession);
      return latestSession.id;
    } else {
      // If only one "in_progress" session exists, set it as current
      const existingSession = sessionsInProgress[0];
      initializeSessionData(existingSession);
      return existingSession.id;
    }
  };

  const initializeWebSocket = (sessionId: string) => {
    ws.current = new WebSocket(`${SERVER_WS_URL}?sessionId=${sessionId}`);
    ws.current.onmessage = handleWebSocketMessage;
  };

  const handleWebSocketMessage = (event: MessageEvent) => {
    resetLastActivity();

    if (!userId || !sessionId) return;

    saveMessageToMessageHistory(userId, sessionId, event.data);
  };

  const checkSessionHealth = () => {
    const now = new Date();
    const timeSinceLastActivity =
      now.getTime() - lastActivityRef.current.getTime();

    // 10 minutes of inactivity save summary
    if (timeSinceLastActivity > 600000) {
      generateSummaryAndTherapyProfile();
      return;
    }
  };

  const generateSummaryAndTherapyProfile = () => {
    const currentSessionId = sessionIdRef.current;

    if (!currentSessionId || !userId || !session) return;

    generateSessionSummary(currentSessionId, session.access_token);
    generateTherapyProfile(currentSessionId);
  };

  const endSession = async (durationMs?: number) => {
    const currentSessionId = sessionIdRef.current;
    if (!currentSessionId) return;

    generateSummaryAndTherapyProfile();

    const durationSeconds = Math.floor((durationMs || 0) / 1000);

    const { error } = await supabase
      .from('sessions')
      .update({
        status: 'completed',
        ended_at: new Date().toISOString(),
        duration_seconds: durationSeconds,
      })
      .eq('id', currentSessionId);

    if (error) {
      return;
    }

    sessionIdRef.current = null;
    setSessionId(null);
    ws.current?.close();
  };

  return {
    resetLastActivity,
    startSession,
    endSession,
  };
};
