import { supabase } from '../supabaseClient';

import { useEffect, useState } from 'react';

export const useAuthState = (initialView: string) => {
  const [authView, setAuthView] = useState(initialView);
  const [defaultEmail, setDefaultEmail] = useState('');
  const [defaultPassword, setDefaultPassword] = useState('');

  useEffect(() => {
    const { data: authListener } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        setAuthView('reset_password');
      } else if (event === 'USER_UPDATED') {
        setAuthView('sign_in');
      }
    });

    setAuthView(initialView);
    return () => authListener.subscription.unsubscribe();
  }, [initialView]);

  return {
    authView,
    setAuthView,
    defaultEmail,
    setDefaultEmail,
    defaultPassword,
    setDefaultPassword,
  };
};
