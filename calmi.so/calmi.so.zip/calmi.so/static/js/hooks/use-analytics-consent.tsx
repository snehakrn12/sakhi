import { ConsentData } from '../types';

import posthog from 'posthog-js';
import { useEffect, useState } from 'react';
import { CONSENT_COOKIE_NAME } from '../constants';
import { CookiePreferences } from '../types';

export const useAnalyticsConsent = () => {
  const [preferences, setPreferences] = useState<CookiePreferences>({
    necessary: true,
    analytics: false,
  });

  const getTimestamp = () => new Date().toISOString();

  const loadPreferences = (): ConsentData | null => {
    const consentCookie = document.cookie
      .split('; ')
      .find((row) => row.startsWith(CONSENT_COOKIE_NAME));

    if (consentCookie) {
      try {
        return JSON.parse(decodeURIComponent(consentCookie.split('=')[1]));
      } catch (e) {
        return null;
      }
    }
    return null;
  };

  const savePreferences = (newPreferences: CookiePreferences) => {
    const expiryDate = new Date();
    expiryDate.setFullYear(expiryDate.getFullYear() + 1);

    const cookieData = {
      preferences: newPreferences,
      lastUpdated: getTimestamp(),
      version: '1.0',
    };

    document.cookie = `${CONSENT_COOKIE_NAME}=${encodeURIComponent(
      JSON.stringify(cookieData)
    )};expires=${expiryDate.toUTCString()};path=/;SameSite=Lax;Secure`;

    setPreferences(newPreferences);
  };

  const updateAnalyticsConsent = (enabled: boolean) => {
    const newPreferences = {
      ...preferences,
      analytics: enabled,
    };

    savePreferences(newPreferences);

    if (enabled) {
      // Initialize PostHog if analytics is enabled
      if (typeof window !== 'undefined') {
        posthog.init(process.env.REACT_APP_PUBLIC_POSTHOG_KEY!, {
          api_host: process.env.REACT_APP_PUBLIC_POSTHOG_HOST,
          person_profiles: 'identified_only',
          capture_pageview: false,
        });
      }
    } else {
      // Opt out of PostHog tracking
      posthog.opt_out_capturing();
    }
  };

  useEffect(() => {
    const savedPreferences = loadPreferences();
    if (savedPreferences) {
      setPreferences(savedPreferences.preferences);
      if (savedPreferences.preferences.analytics) {
        // Initialize PostHog if analytics was previously enabled
        if (typeof window !== 'undefined') {
          posthog.init(process.env.REACT_APP_PUBLIC_POSTHOG_KEY!, {
            api_host: process.env.REACT_APP_PUBLIC_POSTHOG_HOST,
            person_profiles: 'identified_only',
            capture_pageview: false,
          });
        }
      }
    }
  }, []);

  return {
    preferences,
    updateAnalyticsConsent,
    loadPreferences,
  };
};
