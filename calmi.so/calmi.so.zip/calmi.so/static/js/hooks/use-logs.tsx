import { useState } from 'react';
import { SessionMessageData } from '../types';

export const useLogs = ({
  isSubscribed = false,
}: {
  isSubscribed: boolean;
}) => {
  const [logs, setLogs] = useState<{ message: string }[]>([]);
  const [assistantMessage, setAssistantMessage] = useState('');

  const clearLogs = () => {
    setLogs([]);
    setAssistantMessage('');
  };

  const logMessage = (sessionMessageData: SessionMessageData) => {
    if (!sessionMessageData.message) return;

    setLogs((prevLogs) => {
      let processedMessage = sessionMessageData.message;

      if (
        processedMessage.includes('listening...') ||
        processedMessage.includes('thinking...')
      ) {
        return prevLogs;
      }

      if (
        processedMessage.startsWith('user:') ||
        processedMessage.startsWith('assistant:') ||
        processedMessage.startsWith('calmi:')
      ) {
        processedMessage = processedMessage.trim();
      }

      if (!processedMessage.startsWith('user:')) {
        const cleanMessage = processedMessage
          .replace(/^(assistant:|calmi:)\s*/i, '')
          .trim();

        if (cleanMessage) {
          setAssistantMessage(cleanMessage.replace('undefined', ''));
        }
      }

      return [...prevLogs, { message: processedMessage }];
    });
  };

  return {
    logs,
    logMessage,
    clearLogs,
    assistantMessage,
  };
};
