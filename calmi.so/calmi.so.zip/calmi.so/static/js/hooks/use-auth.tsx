import { Session } from '@supabase/supabase-js';
import { isPast } from 'date-fns';
import { useCallback, useEffect, useState } from 'react';
import {
  FREE_SESSION_COUNT_LIMIT,
  PLUS_SESSION_COUNT_LIMIT,
  PRO_SESSION_COUNT_LIMIT,
} from '../constants';
import { supabase } from '../supabaseClient';
import { UserWithDetails } from '../types';

export const useAuth = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<UserWithDetails | null>(null);
  const [loadingUser, setLoadingUser] = useState(true);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [sessionCountLimitReached, setSessionCountLimitReached] =
    useState(false);
  const [sessionCount, setSessionCount] = useState(0);

  const getUserDetails = useCallback(async (userId: string) => {
    const { data: userDetails } = await supabase
      .from('users')
      .select()
      .eq('user_id', userId)
      .single();

    return userDetails;
  }, []);

  const refreshUser = useCallback(async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (!session?.user) {
      setUser(null);
      setSession(null);
      setLoadingUser(false);
      setSessionCount(0);
      return;
    }

    const userDetails = await getUserDetails(session.user.id);

    if (userDetails) {
      const userWithDetails = {
        ...session.user,
        ...userDetails,
      };
      const sessionCount = userDetails.session_count ?? 0;
      const subscriptionPlan = userDetails.subscription_plan;
      const plan = subscriptionPlan;
      const planLimit =
        plan === 'plus'
          ? PLUS_SESSION_COUNT_LIMIT
          : plan === 'pro'
          ? PRO_SESSION_COUNT_LIMIT
          : FREE_SESSION_COUNT_LIMIT;

      const subscriptionEndDate = userDetails.subscription_end_date
        ? new Date(userDetails.subscription_end_date)
        : null;
      const isSubscriptionActive =
        subscriptionEndDate && !isPast(subscriptionEndDate);
      const userIsSubscribed = !!(
        userDetails.is_subscribed || isSubscriptionActive
      );

      setUser(userWithDetails);
      setSessionCount(sessionCount);
      setIsSubscribed(userIsSubscribed);

      if (subscriptionPlan === 'unlimited') {
        setSessionCountLimitReached(false);
      } else if (
        userIsSubscribed &&
        (subscriptionPlan === 'plus' || subscriptionPlan === 'pro')
      ) {
        setSessionCountLimitReached(sessionCount >= planLimit);
      } else if (userIsSubscribed && !subscriptionPlan) {
        setSessionCountLimitReached(sessionCount >= planLimit);
      } else {
        const hasReachedFreeLimit = sessionCount >= FREE_SESSION_COUNT_LIMIT;

        setSessionCountLimitReached(hasReachedFreeLimit);
      }
    }

    setSession(session);
    setLoadingUser(false);
  }, [getUserDetails]);

  useEffect(() => {
    const { data: authListener } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (session) {
          if (event !== 'INITIAL_SESSION') {
            refreshUser();
          } else {
            setSession(session);
            setLoadingUser(false);
          }
        } else {
          setUser(null);
          setSession(null);
          setLoadingUser(false);
          setSessionCount(0);
        }
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        refreshUser();
      } else {
        setLoadingUser(false);
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [refreshUser]);

  return {
    session,
    user,
    loadingUser,
    isSubscribed,
    sessionCount,
    sessionCountLimitReached,
    refreshUser,
    setSession,
  };
};
