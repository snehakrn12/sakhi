import { useQuery, UseQueryOptions } from '@tanstack/react-query';
import { useAuthContext } from '../providers';
import { apiService } from '../utils';
import { toast } from './use-toast';

type HttpMethod = 'get' | 'post' | 'put' | 'delete';

export const useApi = <T,>(
  key: string,
  url: string,
  config?: {
    method?: HttpMethod;
    secure?: boolean;
    queryParams?: Record<string, string | number>;
    body?: object;
    options?: UseQueryOptions<T, Error>;
    onError?: (error: unknown) => void;
  }
) => {
  const { session } = useAuthContext();
  const {
    method = 'get',
    secure = false,
    queryParams,
    body,
    options,
    onError,
  } = config || {};

  return useQuery<T>({
    queryKey: [key, queryParams, body],
    queryFn: async () => {
      try {
        switch (method) {
          case 'post':
            return await apiService.post<T>(url, body ?? {});
          case 'put':
            return await apiService.put<T>(url, body ?? {});
          case 'delete':
            return await apiService.delete<T>(url);
          case 'get':
          default:
            return await apiService.get<T>(url, { params: queryParams ?? {} });
        }
      } catch (error) {
        if (onError) {
          onError(error);
        } else {
          toast({
            title: 'whoops!',
            description: 'An error occurred while fetching data.',
            variant: 'destructive',
          });
        }
        throw error;
      }
    },
    enabled: !secure || !!session,
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false,
    retry: 1,
    ...options,
  });
};
