import posthog from 'posthog-js';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  AppSidebar,
  AppSidebarHeader,
  PostHogPageLeaveTracker,
  PostHogPageViewTracker,
  SidebarInset,
  SidebarProvider,
} from './components';
import { PHProvider, useAuthContext } from './providers';
import { supabase } from './supabaseClient';
import { cn } from './utils';

const Layout = () => {
  const {
    user,
    refreshUser,
    isSubscribed,
    sessionCountLimitReached,
    sessionCount,
    session,
    setSession,
  } = useAuthContext();
  const { pathname } = useLocation();
  const navigate = useNavigate();

  const showWithoutSidebar = pathname === '/pricing';

  const headerPageTitle = () => {
    switch (pathname) {
      case '/history':
        return 'history';
      case '/account':
        return 'account';
      case '/profile':
        return 'profile';
      default:
        return null;
    }
  };

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      return;
    }
    posthog.reset(true);
    setSession(null);
    navigate('/');
  };

  return (
    <>
      <PHProvider>
        {!session || showWithoutSidebar ? (
          <div className='w-full'>
            <Outlet context={{ user, refreshUser }} />{' '}
          </div>
        ) : (
          <SidebarProvider>
            <AppSidebar
              currentPathname={pathname}
              session={session}
              isSubscribed={isSubscribed}
              sessionCountLimitReached={sessionCountLimitReached}
              sessionCount={sessionCount}
              handleLogout={handleLogout}
              subscriptionPlan={user?.subscription_plan ?? null}
            />

            <SidebarInset>
              <AppSidebarHeader
                headerPageTitle={headerPageTitle()}
                pathname={pathname}
              />
              <div className={cn(user && 'px-5 pb-12')}>
                <Outlet context={{ user, refreshUser }} />
              </div>
            </SidebarInset>
          </SidebarProvider>
        )}
        <PostHogPageViewTracker />
        <PostHogPageLeaveTracker />
      </PHProvider>
    </>
  );
};

export default Layout;
