import { Session } from '@supabase/supabase-js';
import axios from 'axios';

export const apiClient = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
});

export const setAuthToken = (session: Session | null) => {
  if (session) {
    apiClient.defaults.headers.common[
      'Authorization'
    ] = `Bearer ${session.access_token}`;
  } else {
    delete apiClient.defaults.headers.common['Authorization'];
  }
};
