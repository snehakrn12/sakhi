export const CONSENT_COOKIE_NAME = 'cookie-consent-settings';
