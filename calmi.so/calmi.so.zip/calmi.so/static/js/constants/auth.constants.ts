import { Provider } from '@supabase/supabase-js';

export const AUTH_CONFIG = {
  redirectTo: '/',
  providers: ['google'] as Provider[],
  socialLayout: 'horizontal' as const,
  localization: {
    variables: {
      sign_in: {
        email_label: 'email',
        password_label: 'password',
        email_input_placeholder: 'email',
        password_input_placeholder: 'password',
        button_label: 'log in',
        link_text: 'already have an account? log in',
      },
      sign_up: {
        email_label: 'email',
        password_label: 'password',
        email_input_placeholder: 'email',
        password_input_placeholder: 'password',
        button_label: 'sign up',
      },
      forgotten_password: {
        email_label: 'email',
        email_input_placeholder: 'email',
        button_label: 'reset password',
        loading_button_label: 'sending reset instructions...',
      },
    },
  },
} as const;

export const AUTH_ERROR_MESSAGES = {
  'Invalid login credentials': 'incorrect email or password.',
  'Email not confirmed': 'please verify your email address before signing in.',
  'User already registered': 'an account with this email already exists.',
  'Invalid email': 'please enter a valid email address.',
  'Invalid password': 'please check your password and try again.',
  'Rate limit exceeded': 'too many attempts. please try again later.',
  'Password recovery failed': 'unable to reset password. please try again.',
  'Token expired': 'your session has expired. please log in again.',
  'New password should be different':
    'new password must be different from the current one.',
  'Password update failed': 'unable to update password. please try again.',

  default: 'an error occurred. please try again.',
  network: 'connection error. please check your internet connection.',
  server: 'service temporarily unavailable. please try again later.',
} as const;

export const AUTH_ROUTE_PARAM = 'auth';
export const AUTH_VIEW_QUERY_PARAM = 'view';
export const AUTH_QUERY_PARAM_SIGN_IN = 'sign_in';
export const AUTH_QUERY_PARAM_SIGN_UP = 'sign_up';
