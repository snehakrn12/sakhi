interface Plan {
  link: string;
  priceId: string;
  price: number;
  name: 'plus' | 'pro' | 'unlimited' | 'testPlus' | 'testPro';
}

const PRODUCTION_PLANS: { [key: string]: Plan } = {
  plus: {
    link: 'https://buy.stripe.com/7sI4j19P57KF82A8wx',
    priceId: 'price_1QWnRvAQBZWZL0qu4ZGuEbs7',
    price: 12,
    name: 'plus',
  },
  pro: {
    link: 'https://buy.stripe.com/14k5n53qHaWReqY3ce',
    priceId: 'price_1QWnTTAQBZWZL0quQdUcY1tI',
    price: 20,
    name: 'pro',
  },
};

const TEST_PLANS: { [key: string]: Plan } = {
  plus: {
    link: 'https://buy.stripe.com/test_aEUaFk0jX8x952M8wx',
    priceId: 'price_1QX3zvAQBZWZL0qu9y5ROtzp',
    price: 12,
    name: 'testPlus',
  },
  pro: {
    link: 'https://buy.stripe.com/test_dR6cNs9Ux5kX9j2146',
    priceId: 'price_1QX422AQBZWZL0qurw8Qu2r2',
    price: 20,
    name: 'testPro',
  },
};

export const PLAN =
  process.env.NODE_ENV === 'production' ? PRODUCTION_PLANS : TEST_PLANS;
