import { Feature } from '../types';

export const FEATURES: Feature[] = [
  {
    title: 'therapy on demand',
    description:
      'got stuff on your mind? just start yapping with calmi, your real-time ai therapist that’s ready 24/7.',
    mediaSrc: '/videos/feature-on-demand-v3.mp4',
    bulletPoints: [
      'real-time, voice-based conversation',
      'accessible anytime, anywhere',
      'never need a friend at 3 a.m. again',
    ],
  },
  {
    title: 'safe & sound',
    description:
      'spill all the tea — calmi’s got you. your sessions are secure and confidential.',
    mediaSrc: '/videos/feature-safe-&-sound-v4.mp4',
    bulletPoints: [
      'easy data deletion options',
      'trusted security for your privacy',
      'locked down tighter than your diary',
    ],
  },
  {
    title: 'personalized growth',
    description:
      "calmi remembers your journey. whether it's tracking progress or picking up from where you left off, adapts on every step.",
    mediaSrc: '/videos/feature-personilzation-and-growth-v2.mp4',
    bulletPoints: [
      'memory across sessions',
      'tailored advice based on your past chats',
      'always knows what you’re working on',
    ],
  },
  {
    title: 'gen z mode',
    description: 'because why not? therapy can be fun.',
    mediaSrc: '/videos/feature-gen-z-v2.mp4',
    bulletPoints: [
      'customize your conversation style',
      'optional toggle for gen z mode',
      'calmi just “gets” it',
    ],
  },
];
