import { Partner } from '../types';

export const PARTNERS: Partner[] = [
  {
    src: 'https://storage.googleapis.com/eleven-public-cdn/images/elevenlabs-grants-logo.png',
    alt: 'ElevenLabs Logo',
    className: 'max-h-12 max-w-[260px]',
    link: 'https://elevenlabs.io/text-to-speech',
    linkTitle: 'ElevenLabs Text-to-Speech',
  },
  {
    src: '/images/partners/microsoft-startup-hub_logo.webp',
    alt: 'Microsoft for Startups Founders Hub Logo',
    className: 'max-h-[40px]',
  },
  {
    src: '/images/partners/aws-startup-programs_logo.webp',
    alt: 'AWS Startup Programs Logo',
    className: 'max-h-[36px]',
  },
  {
    src: '/images/partners/inqubate_logo.webp',
    alt: 'inqubate Logo',
    className: 'max-h-7',
  },
  {
    src: '/images/partners/queens-innovation-centre_logo.webp',
    alt: "Dunin-Deshpande Queen's Innovation Centre Logo",
    className: 'max-h-12',
  },
];

export const DUPLICATED_PARTNERS = [
  ...(PARTNERS ?? []),
  ...(PARTNERS ?? []),
  ...(PARTNERS ?? []),
  ...(PARTNERS ?? []),
];
