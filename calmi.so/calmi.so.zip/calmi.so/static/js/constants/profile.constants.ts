export const PROFILE_TAB_QUERY_PARAM = 'tab';
export const PROFILE_ROUTE_HISTORY_QUERY_PARAM = 'history';
