import { Label } from './ui/label';
import { Switch } from './ui/switch';

interface SessionModeSwitchProps {
  isGenZMode: boolean;
  disabled: boolean;
  setIsGenZMode: (isGenZMode: boolean) => void;
}

export const SessionModeSwitch = ({
  isGenZMode,
  disabled,
  setIsGenZMode,
}: SessionModeSwitchProps) => {
  return (
    <div className='flex items-center gap-2 justify-end h-12'>
      <Label
        htmlFor='gen-z-mode'
        className={disabled ? 'text-primary/50 pointer-events-none' : ''}
      >
        gen z mode
      </Label>
      <Switch
        disabled={disabled}
        id='gen-z-mode'
        checked={isGenZMode}
        onCheckedChange={setIsGenZMode}
      />
    </div>
  );
};
