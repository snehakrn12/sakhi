import { useState } from 'react';
import { Link } from 'react-router-dom';
import { UserWithDetails } from '../../types';
import { ConfirmDialog } from '../confirm-dialog';
import { Button } from '../ui/button';

interface AccountUserProps {
  user: UserWithDetails;
  subscriptionEndDate: string | null;
  isSubscriptionExpired: boolean;
  onCancelSubscription: () => void;
}

export const AccountSubscriptionSettings = ({
  user,
  subscriptionEndDate,
  isSubscriptionExpired,
  onCancelSubscription,
}: AccountUserProps) => {
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);

  return (
    <div>
      <div>
        <h2 className='text-xl font-semibold'>subscription settings</h2>
        <p className='font-semibold mt-1 text-zinc-600'>
          manage subscription settings
        </p>
      </div>

      {/* Subscription Canceled */}
      {!user?.is_subscribed &&
        subscriptionEndDate &&
        !isSubscriptionExpired && (
          <p className='mt-4 text-sm font-medium'>
            <span>
              your subscription has been canceled and is active until:
            </span>{' '}
            <span className='font-bold'>{subscriptionEndDate}</span>
          </p>
        )}

      {/* Is Subscribed */}
      {user?.is_subscribed ? (
        <>
          <Button
            variant='outline'
            className='mt-4'
            onClick={() => setIsConfirmDialogOpen(true)}
          >
            cancel subscription
          </Button>

          <ConfirmDialog
            handleConfirm={onCancelSubscription}
            headline='want to cancel for real?'
            description="no worries, we won't pull the plug right away. you can keep using calmi until your current month runs out."
            open={isConfirmDialogOpen}
            onOpenChange={setIsConfirmDialogOpen}
          />
        </>
      ) : (
        // Not subscribed
        <Button
          asChild
          variant='outline'
          size='sm'
          className='mt-4 max-w-fit justify-self-center pointer-events-auto'
        >
          <Link to='/pricing' className='pointer-events-auto'>
            upgrade
          </Link>
        </Button>
      )}
    </div>
  );
};
