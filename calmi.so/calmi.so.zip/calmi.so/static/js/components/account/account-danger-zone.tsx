import { useState } from 'react';
import { UserWithDetails } from '../../types';
import { ConfirmDialog } from '../confirm-dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';

interface AccountUserProps {
  user: UserWithDetails;
  isDeletingLoading: boolean;
  isResettingChatLoading: boolean;
  onResetChatHistory: (password: string) => void;
  onDeleteUser: (password: string) => void;
}

export const AccountDangerZone = ({
  user,
  isDeletingLoading,
  isResettingChatLoading,
  onResetChatHistory,
  onDeleteUser,
}: AccountUserProps) => {
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [password, setPassword] = useState('');

  const isEmailProvider = user.app_metadata?.provider === 'email';

  return (
    <div className='grid gap-5'>
      <div>
        <h2 className='text-xl font-semibold'>danger zone</h2>
        <p className='font-semibold mt-1 text-zinc-600'>
          be careful with these settings
        </p>
      </div>

      <div className='max-w-80 grid gap-2'>
        <ConfirmDialog
          handleConfirm={() => onResetChatHistory(password)}
          headline='reset chat history - be careful!'
          description="if you confirm, your chat history will be reset and calmi won't remember anything you've chatted about."
          confirmButtonText='reset chat history'
          confirmButtonColor='destructive'
          loading={isResettingChatLoading}
          open={isConfirmDialogOpen}
          onOpenChange={setIsConfirmDialogOpen}
        >
          <div className='grid gap-2 mt-4'>
            <Label htmlFor='password'>password</Label>
            <Input
              id='password'
              type='password'
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder='enter your password'
            />
          </div>
        </ConfirmDialog>

        <Button
          onClick={() => setIsConfirmDialogOpen(true)}
          className='max-w-min'
          variant='outline'
        >
          reset chat history
        </Button>
        <p className='text-sm text-zinc-500'>
          this will reset all of your previous conversations and you start from
          a clean slate. calmi will not remember what you’ve talked about
          earlier.
        </p>
      </div>

      <div className='max-w-80 grid gap-2'>
        <ConfirmDialog
          open={isDeleteDialogOpen}
          onOpenChange={setIsDeleteDialogOpen}
          headline='delete account - this cannot be undone!'
          description='this will permanently delete your account and all associated data.'
          confirmButtonText='delete account'
          confirmButtonColor='dangerOutline'
          loading={isDeletingLoading}
          handleConfirm={() => {
            onDeleteUser(password);
            setPassword('');
          }}
        >
          {isEmailProvider && (
            <div className='grid gap-2 mt-4'>
              <Label htmlFor='password'>password</Label>
              <Input
                id='password'
                type='password'
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder='enter your password'
              />
            </div>
          )}
        </ConfirmDialog>

        <Button
          onClick={() => setIsDeleteDialogOpen(true)}
          variant='dangerOutline'
          className='max-w-min'
        >
          delete account
        </Button>
        <p className='text-sm text-zinc-500'>
          this will delete your account and everything related to it. be
          careful, it cannot be undone.
        </p>
      </div>
    </div>
  );
};
