import { Skeleton } from '../ui/skeleton';

export const AccountPageSkeleton = () => {
  return (
    <div className='grid gap-8'>
      {/* User Info Section */}
      <div className='grid gap-8 w-full'>
        <div className='flex items-center gap-4'>
          <Skeleton className='w-16 h-16 rounded-full' />
          <Skeleton className='h-6 w-48' />
        </div>
      </div>

      <div className='w-full h-[1px] bg-neutral-200' />

      {/* Privacy Settings Section */}
      <div className='w-full'>
        <div>
          <Skeleton className='h-7 w-48' />
          <Skeleton className='h-6 w-72 mt-1' />
        </div>
        <div className='grid gap-4 mt-4'>
          {/* Toggle Items */}
          {[1, 2].map((i) => (
            <div key={i} className='flex items-start gap-2'>
              <Skeleton className='h-6 w-11 rounded-full mt-[6px]' />
              <div className='space-y-1'>
                <Skeleton className='h-[21px] w-32' />

                <div>
                  <Skeleton className='h-[18px] w-64' />
                  <Skeleton className='h-[18px] w-56 mt-1' />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className='w-full h-[1px] bg-neutral-200' />

      {/* Subscription Settings Section */}
      <div className='w-full'>
        <div>
          <Skeleton className='h-7 w-48' />
          <Skeleton className='h-6 w-56 mt-1' />
        </div>
        <Skeleton className='h-8 w-48 mt-4 rounded-lg' />
      </div>
      <div className='w-full h-[1px] bg-neutral-200' />
      {/* Danger Zone Section */}
      <div className='grid gap-5'>
        <div>
          <Skeleton className='h-7 w-48' />
          <Skeleton className='h-6 w-56 mt-1' />
        </div>

        {/* Reset Chat History */}
        <div className='max-w-64 grid gap-2'>
          <Skeleton className='h-8 w-32 rounded-lg' />
          <div>
            <Skeleton className='h-[18px] w-64' />
            <Skeleton className='h-[18px] w-56 mt-1' />
            <Skeleton className='h-[18px] w-48 mt-1' />
          </div>
        </div>

        {/* Delete Account */}
        <div className='max-w-64 grid gap-2'>
          <Skeleton className='h-8 w-32 rounded-lg' />
          <div>
            <Skeleton className='h-[18px] w-64' />
            <Skeleton className='h-[18px] w-56 mt-1' />
            <Skeleton className='h-[18px] w-48 mt-1' />
          </div>
        </div>
      </div>
    </div>
  );
};
