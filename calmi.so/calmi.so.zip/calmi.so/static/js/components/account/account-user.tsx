import { UserIcon } from 'lucide-react';
import { UserWithDetails } from '../../types';

interface AccountUserProps {
  user: UserWithDetails;
}

export const AccountUser = ({ user }: AccountUserProps) => {
  const profilePicture = user?.user_metadata?.avatar_url;

  return (
    <div className='grid gap-8'>
      <div className='flex items-center gap-4'>
        <div className='w-16 aspect-square flex justify-center items-center rounded-full bg-zinc-200'>
          {profilePicture ? (
            <img
              src={profilePicture}
              alt={`${user.email}'s profile`}
              className='rounded-full'
              loading='lazy'
            />
          ) : (
            <UserIcon className='w-8 h-8 text-zinc-500' />
          )}
        </div>

        <p>{user.email}</p>
      </div>
    </div>
  );
};
