import { toast, useAnalyticsConsent } from '../../hooks';
import { Label } from '../ui/label';
import { Switch } from '../ui/switch';

export const AccountPrivacySettings = () => {
  const { preferences, updateAnalyticsConsent } = useAnalyticsConsent();

  const onChangeAnalyticsConsent = (checked: boolean) => {
    updateAnalyticsConsent(checked);

    toast({
      title: checked
        ? 'you agreed on analytics. high five!'
        : 'analytics have been turned off.',
    });
  };

  return (
    <div>
      <div>
        <h2 className='text-xl font-semibold'>privacy settings</h2>
        <p className='font-medium mt-1 text-zinc-600'>
          manage your cookie and tracking preferences
        </p>
      </div>

      <div className='grid gap-4 mt-4'>
        <div className='flex items-start gap-2'>
          <Switch checked disabled className='mt-[6px]' />
          <div className='space-y-1'>
            <Label>necessary cookies</Label>
            <p className='text-sm text-zinc-500'>
              required for the website to function properly. cannot be disabled.
            </p>
          </div>
        </div>

        <div className='flex items-start gap-2'>
          <Switch
            className='mt-[6px]'
            id='analytics'
            checked={preferences.analytics}
            onCheckedChange={(checked) => onChangeAnalyticsConsent(checked)}
          />
          <div className='space-y-1'>
            <Label htmlFor='analytics'>analytics cookies</Label>
            <p className='text-sm text-zinc-500'>
              help us understand how visitors interact with our website using
              PostHog analytics.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
