import { useMutation } from '@tanstack/react-query';
import axios, { AxiosError } from 'axios';
import { ThumbsUp } from 'lucide-react';
import { FormEvent, useEffect, useState } from 'react';
import { toast } from '../hooks';
import { useAuthContext } from '../providers';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Label } from './ui/label';
import { SidebarMenuButton, SidebarMenuItem } from './ui/sidebar';
import { Textarea } from './ui/textarea';

interface FeedbackFormProps {
  showTitle?: boolean;
  isInSidebar?: boolean;
  onFeedbackClick?: () => void;
}

export function FeedbackForm({
  showTitle = true,
  isInSidebar = false,
  onFeedbackClick,
}: FeedbackFormProps) {
  const { session } = useAuthContext();
  const [feedback, setFeedback] = useState('');
  const [open, setOpen] = useState(false);
  const [shouldOpen, setShouldOpen] = useState(false);

  // Use useEffect to handle the dialog opening after the sidebar closes
  useEffect(() => {
    if (shouldOpen) {
      const timer = setTimeout(() => {
        setOpen(true);
        setShouldOpen(false);
      }, 100); // Small delay to ensure sidebar closes first
      return () => clearTimeout(timer);
    }
  }, [shouldOpen]);

  const handleFeedbackClick = () => {
    setShouldOpen(true);
    onFeedbackClick?.();
  };

  const { mutate: handleAddFeedback, isPending } = useMutation({
    mutationFn: async () => {
      const token = session?.access_token;

      return axios.post(
        `${process.env.REACT_APP_API_URL}/feedback`,
        {
          feedback,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
    },
    onError: (error) => {
      if (error instanceof AxiosError) {
        return toast({
          title: 'error!',
          description: `an error occurred while submitting feedback, try again or contact support.`,
          variant: 'destructive',
        });
      }
    },
    onSuccess: () => {
      return toast({
        title: 'high five! thanks for the feedback.',
      });
    },
  });

  const submitFeedback = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    handleAddFeedback();
    setOpen(false);
  };

  const triggerButton = (
    <button onClick={handleFeedbackClick} className='flex items-center gap-2'>
      <span>
        <ThumbsUp className='w-5 h-5' />
      </span>
      {showTitle && <span>feedback</span>}
    </button>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {isInSidebar ? (
          <SidebarMenuItem className='flex items-center gap-2'>
            <SidebarMenuButton asChild tooltip='feedback'>
              {triggerButton}
            </SidebarMenuButton>
          </SidebarMenuItem>
        ) : (
          triggerButton
        )}
      </DialogTrigger>

      <DialogContent
        overlayClassName='bg-black/20'
        className='max-w-[95%] sm:max-w-[425px] p-3 sm:p-3 mx-auto rounded-lg [&>button]:hidden'
      >
        <form onSubmit={submitFeedback}>
          <DialogHeader className='sr-only'>
            <DialogTitle>give feedback</DialogTitle>
            <DialogDescription>
              we'd love to hear from you! Please share your thoughts and
              suggestions.
            </DialogDescription>
          </DialogHeader>
          <div className='grid grid-cols-4 items-center gap-2'>
            <Label className='sr-only' htmlFor='feedback'>
              feedback
            </Label>
            <Textarea
              autoFocus
              id='feedback'
              placeholder='how can we improve calmi?'
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              className='col-span-4 border-0 focus-visible:ring-0 min-h-[150px] text-base'
            />
          </div>
          <DialogFooter>
            <div className='flex justify-between w-full mt-3'>
              <Button
                variant='secondary'
                type='button'
                onClick={() => setOpen(false)}
              >
                cancel
              </Button>

              <Button variant='primary' type='submit' disabled={isPending}>
                {isPending ? 'submitting...' : 'submit'}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
