import { Pause, Play } from 'lucide-react';
import React, { useRef, useState } from 'react';
import { Button } from './ui/button';

interface AudioPlayerProps {
  src: string;
  showProgressBar?: boolean;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
  src,
  showProgressBar = true,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      const progressPercent =
        (audioRef.current.currentTime / audioRef.current.duration) * 100;
      setProgress(progressPercent);
    }
  };

  const handleProgressBarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (audioRef.current && progressBarRef.current) {
      const progressBar = progressBarRef.current;
      const clickPosition = e.nativeEvent.offsetX;
      const progressBarWidth = progressBar.offsetWidth;
      const newTime =
        (clickPosition / progressBarWidth) * audioRef.current.duration;

      audioRef.current.currentTime = newTime;
      setProgress((clickPosition / progressBarWidth) * 100);
    }
  };

  return (
    <div className='flex items-center w-full'>
      <audio
        ref={audioRef}
        src={src}
        onTimeUpdate={handleTimeUpdate}
        onEnded={() => setIsPlaying(false)}
      />

      <div className='mr-4'>
        <Button
          variant='ghost'
          size='icon'
          className='w-12 h-12 rounded-full bg-zinc-100 hover:bg-zinc-200 active:bg-zinc-300 focus-visible:bg-zinc-300 transition-colors'
          onClick={togglePlay}
        >
          {isPlaying ? (
            <Pause size={20} fill='black' />
          ) : (
            <Play size={20} fill='black' />
          )}
        </Button>
      </div>

      {showProgressBar && (
        <div
          ref={progressBarRef}
          className='flex-grow h-2 bg-zinc-200 rounded-full cursor-pointer'
          onClick={handleProgressBarClick}
        >
          <div
            className='h-full bg-zinc-900 rounded-full transition-all duration-200'
            style={{ width: `${progress}%` }}
          />
        </div>
      )}
    </div>
  );
};
