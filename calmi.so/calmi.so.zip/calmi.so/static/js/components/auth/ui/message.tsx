import { cn } from '../../../utils';

interface MessageProps extends React.HTMLAttributes<HTMLSpanElement> {
  children: React.ReactNode;
  color?: 'danger';
}

const Message: React.FC<MessageProps> = ({ children, ...props }) => {
  return (
    <span
      {...props}
      className={cn(
        'border rounded-md p-2 text-sm',
        props.color === 'danger'
          ? 'text-destructive/80 border-destructive/80'
          : 'text-green-600/80 border-green-600/80'
      )}
    >
      {children}
    </span>
  );
};

export { Message };
