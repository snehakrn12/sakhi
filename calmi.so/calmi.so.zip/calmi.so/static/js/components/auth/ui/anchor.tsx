interface LabelProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  children: React.ReactNode;
}

const Anchor: React.FC<LabelProps> = ({ children, ...props }) => {
  return (
    <a
      {...props}
      className='text-center text-sm text-zinc-500 hover:text-zinc-400 active:text-zinc-600 focus-visible:text-zinc-400 transition-colors'
    >
      {children}
    </a>
  );
};

export { Anchor };
