import { I18nVariables } from '@supabase/auth-ui-shared';
import { SupabaseClient } from '@supabase/supabase-js';
import { CircleAlert, Info } from 'lucide-react';
import React, { useState } from 'react';
import { Button, Input, Label } from '../..';
import { AUTH_ERROR_MESSAGES } from '../../../constants';
import { sanitizeErrorMessage } from '../../../utils';
import { Message } from '../ui';

function UpdatePassword({
  supabaseClient,
  i18n,
  passwordLimit = false,
}: {
  supabaseClient: SupabaseClient;
  i18n?: I18nVariables;
  passwordLimit?: boolean;
}) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handlePasswordReset = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);
    try {
      if (passwordLimit && password.length > 72) {
        setError('password exceeds maximum length of 72 characters');
        return;
      }
      const { error } = await supabaseClient.auth.updateUser({ password });
      if (error) {
        setError(sanitizeErrorMessage(error.message));
      } else {
        setMessage(i18n?.update_password?.confirmation_text as string);
      }
    } catch (error) {
      setError(AUTH_ERROR_MESSAGES.server);
    } finally {
      setLoading(false);
    }
  };

  const labels = i18n?.update_password;

  return (
    <form id='auth-update-password' onSubmit={handlePasswordReset}>
      <div>
        <Label htmlFor='password'>{labels?.password_label}</Label>
        <Input
          id='password'
          name='password'
          placeholder={labels?.password_input_placeholder}
          type='password'
          autoFocus
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setPassword(e.target.value)
          }
        />
      </div>
      <Button type='submit' color='primary' disabled={loading}>
        {loading ? labels?.loading_button_label : labels?.button_label}
      </Button>
      {message && (
        <Message>
          <p className='flex items-center gap-2'>
            <Info className='w-5 h-5' /> <span>{message}</span>
          </p>
        </Message>
      )}
      {error && (
        <Message color='danger'>
          <p className='flex items-center gap-2'>
            <CircleAlert className='w-5 h-5' /> <span>{error}</span>
          </p>
        </Message>
      )}
    </form>
  );
}

export { UpdatePassword };
