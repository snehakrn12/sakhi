import { I18nVariables, RedirectTo, VIEWS } from '@supabase/auth-ui-shared';
import { SupabaseClient } from '@supabase/supabase-js';
import { CircleAlert, Info } from 'lucide-react';
import React, { useState } from 'react';
import { Button, Input, Label } from '../..';
import { AUTH_ERROR_MESSAGES } from '../../../constants';
import { sanitizeErrorMessage } from '../../../utils';
import { Anchor, Message } from '../ui';

function ForgottenPassword({
  setAuthView = () => {},
  supabaseClient,
  redirectTo,
  i18n,
  showLinks = false,
}: {
  setAuthView?: any;
  supabaseClient: SupabaseClient;
  redirectTo?: RedirectTo;
  i18n?: I18nVariables;
  showLinks?: boolean;
}) {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handlePasswordReset = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    try {
      const { error } = await supabaseClient.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/reset-password`,
      });

      if (error) {
        setError(sanitizeErrorMessage(error.message));
      } else {
        setMessage(
          'If an account exists with this email, you will receive password reset instructions.'
        );
      }
    } catch (error) {
      setError(AUTH_ERROR_MESSAGES.server);
    } finally {
      setLoading(false);
    }
  };

  const labels = i18n?.forgotten_password;

  return (
    <form
      className='grid gap-4'
      id='auth-forgot-password'
      onSubmit={handlePasswordReset}
    >
      <div>
        <Label htmlFor='email'>{labels?.email_label}</Label>
        <Input
          id='email'
          name='email'
          type='email'
          autoFocus
          placeholder={labels?.email_input_placeholder}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setEmail(e.target.value)
          }
        />
      </div>
      <Button
        type='submit'
        variant='outline'
        size='md'
        disabled={loading || !email.length}
      >
        {loading ? labels?.loading_button_label : labels?.button_label}
      </Button>
      {showLinks && (
        <Anchor
          href='#auth-sign-in'
          onClick={(e: React.MouseEvent<HTMLAnchorElement>) => {
            e.preventDefault();
            setAuthView(VIEWS.SIGN_IN);
          }}
        >
          <p className='lowercase text-sm text-zinc-500'>
            {i18n?.sign_in?.link_text}
          </p>
        </Anchor>
      )}
      {message && (
        <Message>
          <p className='flex items-center gap-2'>
            <Info className='w-5 min-w-5 h-5' /> <span>{message}</span>
          </p>
        </Message>
      )}
      {error && (
        <Message color='danger'>
          <p className='flex items-center gap-2'>
            <CircleAlert className='w-5 min-w-5 h-5' /> <span>{error}</span>
          </p>
        </Message>
      )}
    </form>
  );
}

export { ForgottenPassword };
