import {
  I18nVariables,
  ProviderScopes,
  SocialLayout,
  template,
} from '@supabase/auth-ui-shared';
import { Provider, SupabaseClient } from '@supabase/supabase-js';
import { useState } from 'react';
import { Button } from '../..';
import { Icons } from '../icons';

interface SocialAuthProps {
  supabaseClient: SupabaseClient;
  socialLayout?: SocialLayout;
  providers?: Provider[];
  providerScopes?: Partial<ProviderScopes>;
  queryParams?: { [key: string]: string };
  redirectTo?: RedirectTo;
  onlyThirdPartyProviders?: boolean;
  view?: 'sign_in' | 'sign_up' | 'magic_link';
  i18n?: I18nVariables;
}

type RedirectTo = undefined | string;

function SocialAuth({
  supabaseClient,
  socialLayout = 'vertical',
  providers = ['github', 'google', 'azure'],
  providerScopes,
  queryParams,
  redirectTo,
  onlyThirdPartyProviders = true,
  view = 'sign_in',
  i18n,
}: SocialAuthProps) {
  const [loading, setLoading] = useState(false);
  const [hasError, setHasError] = useState(false);

  const verticalSocialLayout = socialLayout === 'vertical' ? true : false;

  const currentView = view === 'magic_link' ? 'sign_in' : view;

  const handleProviderSignIn = async (provider: Provider) => {
    setLoading(true);
    const { error } = await supabaseClient.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo,
        scopes: providerScopes?.[provider],
        queryParams,
      },
    });

    if (error) setHasError(true);

    setLoading(false);
  };

  function handleProviderNameEdgeCases(provider: string) {
    if (provider === 'linkedin_oidc') {
      return 'LinkedIn';
    }
    return provider;
  }

  function capitalize(word: string) {
    const lower = word.toLowerCase();
    return word.charAt(0).toUpperCase() + lower.slice(1);
  }

  return (
    <>
      {providers && providers.length > 0 && (
        <>
          {providers.map((provider: Provider) => {
            return (
              <Button
                size='md'
                className='w-full'
                key={provider}
                color='default'
                disabled={loading}
                onClick={() => handleProviderSignIn(provider)}
                variant='outline'
              >
                <Icons provider={provider} />
                {verticalSocialLayout &&
                  template(
                    i18n?.[currentView]?.social_provider_text as string,
                    {
                      provider: capitalize(
                        handleProviderNameEdgeCases(provider)
                      ),
                    }
                  )}
              </Button>
            );
          })}

          {hasError && (
            <p className='text-red-500 border border-red-500 rounded-md p-2 mt-4'>
              whoops! something went wrong. pls try again.
            </p>
          )}
        </>
      )}
    </>
  );
}

export { SocialAuth };
