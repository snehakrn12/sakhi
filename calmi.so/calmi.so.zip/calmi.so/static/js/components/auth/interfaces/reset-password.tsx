import { SupabaseClient } from '@supabase/supabase-js';
import { CircleAlert } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Input, Label } from '../..';
import { sanitizeErrorMessage, validatePassword } from '../../../utils';
import { Message } from '../ui';

interface ResetPasswordProps {
  supabaseClient: SupabaseClient;
}

export function ResetPassword({ supabaseClient }: ResetPasswordProps) {
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [tokenValidated, setTokenValidated] = useState(false);

  useEffect(() => {
    const handlePasswordReset = async () => {
      const hashFragment = decodeURIComponent(window.location.hash);

      if (!hashFragment) {
        navigate('/auth/signin');
        return;
      }

      try {
        // Extract the token from the URL hash
        const accessToken = hashFragment
          .split('access_token=')[1]
          ?.split('&')[0];
        const type = hashFragment.split('type=')[1]?.split('&')[0];
        const refreshToken = hashFragment
          .split('refresh_token=')[1]
          ?.split('&')[0];

        if (!accessToken || type !== 'recovery') {
          setError('Invalid reset token');
          setTimeout(() => navigate('/auth/signin'), 3000);
          return;
        }

        // Set the session with both tokens
        const {
          data: { session },
          error: sessionError,
        } = await supabaseClient.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken || '',
        });

        if (sessionError || !session) {
          setError('Invalid or expired reset token');
          setTimeout(() => navigate('/auth/signin'), 3000);
          return;
        }

        setTokenValidated(true);
      } catch (error) {
        setError('Invalid reset token');
        setTimeout(() => navigate('/auth/signin'), 3000);
      }
    };

    handlePasswordReset();
  }, [navigate, supabaseClient.auth]);

  const handlePasswordReset = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (password !== confirmPassword) {
      setError('passwords do not match');
      setLoading(false);
      return;
    }

    const { isValid, error: validationError } = validatePassword(password);
    if (!isValid) {
      setError(validationError);
      setLoading(false);
      return;
    }

    try {
      const { error } = await supabaseClient.auth.updateUser({
        password,
      });

      if (error) {
        setError(sanitizeErrorMessage(error.message));
      } else {
        // Sign out and redirect
        await supabaseClient.auth.signOut({ scope: 'global' });
        navigate('/auth/signin?reset=success');
      }
    } catch (error) {
      setError('failed to reset password. please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Only show the form if the token is validated
  if (!tokenValidated) {
    return (
      <div className='grid gap-4'>
        {error && (
          <Message color='danger'>
            <p className='flex items-center gap-2'>
              <CircleAlert className='w-5 h-5' /> <span>{error}</span>
            </p>
          </Message>
        )}
      </div>
    );
  }

  return (
    <form className='grid gap-4' onSubmit={handlePasswordReset}>
      <div>
        <Label htmlFor='password'>new password</Label>
        <Input
          id='password'
          name='password'
          type='password'
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder='enter your new password'
        />
      </div>

      <div>
        <Label htmlFor='confirmPassword'>confirm password</Label>
        <Input
          id='confirmPassword'
          name='confirmPassword'
          type='password'
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          placeholder='confirm your new password'
        />
      </div>

      <Button
        type='submit'
        variant='outline'
        size='md'
        disabled={loading || !password || !confirmPassword}
      >
        {loading ? 'updating password...' : 'update password'}
      </Button>

      {error && (
        <Message color='danger'>
          <p className='flex items-center gap-2'>
            <CircleAlert className='w-5 h-5' /> <span>{error}</span>
          </p>
        </Message>
      )}
    </form>
  );
}
