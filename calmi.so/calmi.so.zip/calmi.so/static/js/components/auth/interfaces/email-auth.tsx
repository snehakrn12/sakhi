import {
  I18nVariables,
  RedirectTo,
  VIEWS,
  ViewSignIn,
  ViewSignUp,
  ViewType,
} from '@supabase/auth-ui-shared';
import { SupabaseClient } from '@supabase/supabase-js';
import { useMutation } from '@tanstack/react-query';
import axios from 'axios';
import { CircleAlert, Info } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { Button, Input, Label } from '../../';
import { sanitizeErrorMessage, validatePassword } from '../../../utils';
import { Anchor, Message } from '../ui';

export interface EmailAuthProps {
  authView?: ViewSignIn | ViewSignUp;
  defaultEmail?: string;
  defaultPassword?: string;
  setAuthView?: any;
  setDefaultEmail?: (email: string) => void;
  setDefaultPassword?: (password: string) => void;
  supabaseClient: SupabaseClient;
  showLinks?: boolean;
  redirectTo?: RedirectTo;
  additionalData?: { [key: string]: any };
  magicLink?: boolean;
  i18n?: I18nVariables;
  passwordLimit?: boolean;
  children?: React.ReactNode;
}

function EmailAuth({
  authView = 'sign_in',
  defaultEmail = '',
  defaultPassword = '',
  setAuthView = () => {},
  setDefaultEmail = (email) => {},
  setDefaultPassword = (password) => {},
  supabaseClient,
  showLinks = false,
  redirectTo,
  additionalData,
  magicLink,
  i18n,
  passwordLimit = false,
  children,
}: EmailAuthProps) {
  const isMounted = useRef<boolean>(true);
  const [email, setEmail] = useState(defaultEmail);
  const [password, setPassword] = useState(defaultPassword);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const { mutate: addNewUserToResendAudience } = useMutation({
    mutationFn: ({ email, userId }: { email: string; userId: string }) => {
      return axios.post(
        `${process.env.REACT_APP_API_URL}/add-new-user-to-audience`,
        {
          email,
          userId,
        }
      );
    },
  });

  useEffect(() => {
    isMounted.current = true;
    setEmail(defaultEmail);
    setPassword(defaultPassword);

    return () => {
      isMounted.current = false;
    };
  }, [authView]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    switch (authView) {
      case 'sign_in':
        const { error: signInError } =
          await supabaseClient.auth.signInWithPassword({
            email,
            password,
          });
        if (signInError) {
          setError(sanitizeErrorMessage(signInError.message));
        } else if (redirectTo) {
          window.location.href = redirectTo;
        }
        break;
      case 'sign_up':
        const { isValid, error } = validatePassword(password);
        if (!isValid) {
          setError(error);
          setLoading(false);
          return;
        }
        let options: { emailRedirectTo: RedirectTo; data?: object } = {
          emailRedirectTo: redirectTo,
        };
        if (additionalData) {
          options.data = additionalData;
        }
        const {
          data: { user: signUpUser, session: signUpSession },
          error: signUpError,
        } = await supabaseClient.auth.signUp({
          email,
          password,
          options,
        });

        if (signUpError) setError(signUpError.message);
        // Check if session is null -> email confirmation setting is turned on
        else if (signUpUser && !signUpSession)
          setMessage(i18n?.sign_up?.confirmation_text as string);

        const userEmail = signUpUser?.email;

        if (!userEmail) break;

        addNewUserToResendAudience({ email: userEmail, userId: signUpUser.id });
        break;
    }

    /*
     * it is possible the auth component may have been unmounted at this point
     * check if component is mounted before setting a useState
     */
    if (isMounted.current) setLoading(false);
  };

  const handleViewChange = (newView: ViewType) => {
    setDefaultEmail(email);
    setDefaultPassword(password);
    setAuthView(newView);
    setError('');
    setMessage('');
  };

  const labels = i18n?.[authView];

  return (
    <form
      id={authView === 'sign_in' ? `auth-sign-in` : `auth-sign-up`}
      onSubmit={handleSubmit}
      autoComplete={'on'}
      className='w-full grid gap-4'
    >
      <div>
        <Label htmlFor='email'>{labels?.email_label}</Label>
        <Input
          className='mt-1 lowercase'
          id='email'
          type='email'
          name='email'
          placeholder={labels?.email_input_placeholder}
          defaultValue={email}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            setEmail(e.target.value);
            setError('');
          }}
          autoComplete='email'
        />
      </div>
      <div>
        <Label htmlFor='password'>{labels?.password_label}</Label>
        <Input
          className='mt-1 lowercase'
          id='password'
          type='password'
          name='password'
          placeholder={labels?.password_input_placeholder}
          defaultValue={password}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            setPassword(e.target.value);
            setError('');
          }}
          autoComplete={
            authView === 'sign_in' ? 'current-password' : 'new-password'
          }
        />
      </div>
      {children}

      <Button
        size='md'
        className='w-full mt-2'
        type='submit'
        variant='outline'
        disabled={loading || !!error}
      >
        <p className='lowercase'>
          {loading ? labels?.loading_button_label : labels?.button_label}
        </p>
      </Button>

      {showLinks && (
        <div className='grid gap-2 lowercase text-sm text-zinc-500'>
          {authView === VIEWS.SIGN_IN && magicLink && (
            <Anchor
              href='#auth-magic-link'
              onClick={(e: React.MouseEvent<HTMLAnchorElement>) => {
                e.preventDefault();
                setAuthView(VIEWS.MAGIC_LINK);
              }}
            >
              {i18n?.magic_link?.link_text}
            </Anchor>
          )}
          {authView === VIEWS.SIGN_IN && (
            <Anchor
              href='#auth-forgot-password'
              onClick={(e: React.MouseEvent<HTMLAnchorElement>) => {
                e.preventDefault();
                setAuthView(VIEWS.FORGOTTEN_PASSWORD);
              }}
            >
              {i18n?.forgotten_password?.link_text}
            </Anchor>
          )}
          {authView === VIEWS.SIGN_IN ? (
            <Anchor
              href='#auth-sign-up'
              onClick={(e: React.MouseEvent<HTMLAnchorElement>) => {
                e.preventDefault();
                handleViewChange(VIEWS.SIGN_UP);
              }}
            >
              {i18n?.sign_up?.link_text}
            </Anchor>
          ) : (
            <Anchor
              href='#auth-sign-in'
              onClick={(e: React.MouseEvent<HTMLAnchorElement>) => {
                e.preventDefault();
                handleViewChange(VIEWS.SIGN_IN);
              }}
            >
              {i18n?.sign_in?.link_text}
            </Anchor>
          )}
        </div>
      )}
      {message && !error && (
        <Message>
          <p className='flex items-center gap-2'>
            <Info className='w-5 h-5' /> <span>{message}</span>
          </p>
        </Message>
      )}
      {error && (
        <Message color='danger'>
          <p className='flex items-center gap-2'>
            <CircleAlert className='w-5 h-5' /> <span>{error}</span>
          </p>
        </Message>
      )}
    </form>
  );
}

export { EmailAuth };
