import { Quote } from 'lucide-react';
import { useEffect, useState } from 'react';

export const Testimonials = () => {
  const [isAnimated, setIsAnimated] = useState(false);

  const data = [
    {
      name: '@hiral.sidhu',
      comment:
        'I just got on it and thank you sooo much for this is truly helped me',
    },
    {
      name: 'pierce',
      comment:
        "hey! i just tried your ai model and it's sick, i already feel a little better",
    },
    {
      name: '@_hebored_',
      comment: 'Naw tho this really helps',
    },
    {
      name: 'decim0330',
      comment: 'This would actually work on me better than my therapist',
    },
    {
      name: '@_rose_boy_1029',
      comment: 'That shit works a little bit too well',
    },
    {
      name: 'snowphobic',
      comment:
        'this is honestly such a good site and i appreciate the time and dedication you put into making it! i hope this blows up',
    },
    {
      name: '@alisson.music',
      comment: 'GUYS IT WORKS i swear, this made my day',
    },
    {
      name: '@pyrelda',
      comment: 'WOW',
    },
    {
      name: 'mvggotz',
      comment:
        "i'm... speechless. i used this for less than 5 min and i'm already crying... . i really needed this. thank you. so much",
    },
    {
      name: 'gilly.gerel',
      comment: 'damn just had a therapy session',
    },
    {
      name: '@manzanitawoo',
      comment:
        'To be honest I gave it a try and it’s really good I feel better now',
    },
    {
      name: 'orianagxmez',
      comment:
        'I tried it and I can genuinely say - this is insane, I am so amused by how good the AI is',
    },
    {
      name: 'aflynaaa',
      comment: 'THIS ATEEEEE🔥',
    },
    {
      name: '@bubblegum_.v0dka',
      comment: 'omg she’s so cool she actually made me feel better',
    },
    {
      name: 'eggs eggs eggs tentacion',
      comment: 'this literally is the biggest discovery in my life',
    },
    {
      name: 'hope_fm9',
      comment:
        'The best thing ever! I love it im not joking. Thank you very much for this!! 💜',
    },
    {
      name: '@arin.bader.1',
      comment: 'I’m def gonna use this when I need it',
    },
    {
      name: 'taehoonsgf',
      comment:
        '...a lot of people can’t afford therapists and just need someone to vent to, it’s an amazing alternative...',
    },
    {
      name: '@nucci.inc',
      comment: 'Thank you kindly, this changed me',
    },
    {
      name: '@urlove.alg',
      comment:
        'I tried it and it made me feel better! It’s so great because I never talk about how I feel to friends',
    },
  ];

  const addAnimation = () => {
    setIsAnimated(true);
  };

  useEffect(() => {
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      addAnimation();
    }
  }, []);

  const duplicatedList = [...(data ?? []), ...(data ?? [])];

  return (
    <article className='flex flex-col gap-4 overflow-hidden'>
      <ul
        className='animated-moving testimonials'
        data-animated={isAnimated}
        data-direction='left'
        data-duration='slow'
      >
        <div className='inner-scroller'>
          {duplicatedList &&
            duplicatedList.map((testimonial, index) => (
              <div
                key={testimonial.name + index}
                className='flex flex-col gap-2 p-3 max-w-64 sm:max-w-72 md:p-4 md:max-w-96 text-sm font-medium md:text-base border border-zinc-200 rounded-md'
              >
                <div className='flex items-center gap-2'>
                  <Quote className='w-4 h-4' />

                  <p className='text-gray-700 mb-[2px]'>{testimonial.name}</p>
                </div>

                <p>{testimonial.comment}</p>
              </div>
            ))}
        </div>
      </ul>

      <ul
        className='animated-moving testimonials'
        data-animated={isAnimated}
        data-direction='right'
        data-duration='medium'
      >
        <div className='inner-scroller'>
          {duplicatedList &&
            duplicatedList.map((testimonial, index) => (
              <div
                key={testimonial.name + index}
                className='flex flex-col gap-2 p-3 max-w-64 sm:max-w-72 md:p-4 md:max-w-96 text-sm font-medium md:text-base border border-zinc-200 rounded-md'
              >
                <div className='flex items-center gap-2'>
                  <Quote className='w-4 h-4' />

                  <p className='text-gray-700 mb-[2px]'>{testimonial.name}</p>
                </div>

                <p>{testimonial.comment}</p>
              </div>
            ))}
        </div>
      </ul>
    </article>
  );
};
