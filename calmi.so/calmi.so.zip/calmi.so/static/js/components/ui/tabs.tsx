'use client';

import * as React from 'react';
import {
  Link,
  LinkProps,
  useLocation,
  useSearchParams,
} from 'react-router-dom';
import { cn } from '../../utils';

interface Context {
  defaultValue: string;
  hrefFor: (value: string) => LinkProps['to'];
  searchParam: string;
  selected: string;
}
const TabsContext = React.createContext<Context>(null as any);

export function Tabs(props: {
  children: React.ReactNode;
  className?: string;
  /**
   * The default tab
   */
  defaultValue: string;
  /**
   * Which search param to use
   * @default "tab"
   */
  searchParam?: string;
}) {
  const { children, className, searchParam = 'tab', ...other } = props;
  const [searchParams] = useSearchParams();
  const location = useLocation();

  const selected = searchParams.get(searchParam) || props.defaultValue;

  const hrefFor: Context['hrefFor'] = React.useCallback(
    (value) => {
      const params = new URLSearchParams(searchParams);
      if (value === props.defaultValue) {
        params.delete(searchParam);
      } else {
        params.set(searchParam, value);
      }

      const asString = params.toString();

      return location.pathname + (asString ? '?' + asString : '');
    },
    [searchParams, props.defaultValue, searchParam, location.pathname]
  );

  return (
    <TabsContext.Provider value={{ ...other, hrefFor, searchParam, selected }}>
      <div className={className}>{children}</div>
    </TabsContext.Provider>
  );
}

const useContext = () => {
  const context = React.useContext(TabsContext);
  if (!context) {
    throw new Error(
      'Tabs compound components cannot be rendered outside the Tabs component'
    );
  }

  return context;
};

export function TabsList(props: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      {...props}
      className={cn(
        'w-full inline-flex gap-2 h-10 items-center justify-center rounded-lg bg-zinc-200 p-1 text-zinc-500 ',
        props.className
      )}
    />
  );
}

export const TabsTrigger = (props: {
  children: React.ReactNode;
  className?: string;
  value: string;
}) => {
  const context = useContext();

  return (
    <Link
      {...props}
      className={cn(
        'w-full h-full inline-flex items-center justify-center whitespace-nowrap rounded-md font-medium transition-bg transition-colors focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm data-[state=active]:hover:bg-zinc-50 data-[state=active]:active:bg-white data-[state=active]:focus-visible:bg-white data-[state=inactive]:hover:bg-zinc-300 data-[state=inactive]:active:bg-zinc-200 data-[state=inactive]:focus-visible:bg-zinc-200 data-[state=inactive]:hover:text-zinc-800 data-[state=inactive]:active:text-black data-[state=inactive]:focus-visible:text-black',
        props.className
      )}
      data-state={context.selected === props.value ? 'active' : 'inactive'}
      to={context.hrefFor(props.value)}
    />
  );
};

export function TabsContent(props: {
  children: React.ReactNode;
  className?: string;
  value: string;
}) {
  const context = useContext();

  if (context.selected !== props.value) {
    return null;
  }

  return <div {...props} className={cn('mt-2 ', props.className)} />;
}
