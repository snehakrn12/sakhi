'use client';

import * as SwitchPrimitives from '@radix-ui/react-switch';
import * as React from 'react';

import { cn } from '../../utils';

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitives.Root>,
  React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root>
>(({ className, disabled, ...props }, ref) => (
  <SwitchPrimitives.Root
    className={cn(
      'peer inline-flex h-6 w-11 pl-[2px] shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:hover:bg-gray-700 data-[state=checked]:active:bg-gray-600 data-[state=checked]:focus-visible:bg-gray-600 data-[state=unchecked]:bg-zinc-200 data-[state=unchecked]:hover:bg-zinc-300 data-[state=unchecked]:focus-visible:bg-zinc-400 data-[state=unchecked]:active:bg-zinc-400 data-[state=disabled]:opacity-50',
      disabled && 'pointer-events-none',
      className
    )}
    {...props}
    ref={ref}
    disabled={disabled}
  >
    <SwitchPrimitives.Thumb
      className={cn(
        'pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0'
      )}
    />
  </SwitchPrimitives.Root>
));
Switch.displayName = SwitchPrimitives.Root.displayName;

export { Switch };
