import * as React from 'react';

import { cn } from '../../utils';

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  disabled?: boolean;
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, disabled = false, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          'flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 file:border-0 file:bg-transparent file:font-medium file:text-foreground placeholder:text-muted-foreground hover:border-zinc-400 focus-visible:outline-none focus-visible:border-zinc-800 active:border-zinc-800  disabled:cursor-not-allowed disabled:pointer-events-none disabled:opacity-50 transition-colors',
          className,
          disabled && 'cursor-not-allowed pointer-events-none opacity-50'
        )}
        ref={ref}
        {...props}
      />
    );
  }
);
Input.displayName = 'Input';

export { Input };
