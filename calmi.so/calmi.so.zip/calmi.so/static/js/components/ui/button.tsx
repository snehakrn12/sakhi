import { Slot } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';
import * as React from 'react';

import { cn } from '../../utils';

const buttonVariants = cva(
  ' inline-flex items-center justify-center whitespace-nowrap rounded-lg text-base font-semibold transition-colors focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50',
  {
    variants: {
      variant: {
        default:
          'bg-primary text-primary-foreground hover:bg-primary/90 active:bg-primary/80 focus-visible:bg-primary/80',
        primary:
          'bg-accent-default text-accent-foreground hover:bg-accent-hover active:bg-accent-active focus-visible:bg-accent-active disabled:bg-accent-disabled',
        destructive:
          'bg-destructive hover:bg-destructive/90 active:bg-destructive/80 focus-visible:bg-destructive/80',
        dangerOutline:
          'bg-transparent text-destructive border border-destructive hover:border-destructive/80 hover:text-destructive/80 active:border-destructive/60 focus-visible:border-destructive/60 active:text-destructive/60 focus-visible:text-destructive/60',
        outline:
          'bg-transparent text-primary border border-primary hover:border-primary/80 hover:text-primary/80 active:border-primary/60 focus-visible:border-primary/60 active:text-primary/60 focus-visible:text-primary/60',
        secondary:
          'bg-zinc-100 text-secondary-foreground hover:bg-zinc-200 active:bg-zinc-300 focus-visible:bg-zinc-300 disabled:bg-zinc-100 disabled:text-zinc-300',
        ghost: 'hover:bg-accent hover:text-accent-foreground',
        icon: 'bg-transparent p-1 w-min h-min text-zinc-500 hover:text-zinc-600',
        link: 'text-primary underline-offset-4 hover:underline',
      },
      size: {
        default: 'h-8 px-4 py-1',
        sm: 'h-9 px-3',
        md: 'h-10 px-4',
        lg: 'h-12 px-4 py-3 text-xl',
        icon: 'h-12 w-12 p-2',
      },
      iconSize: {
        default: 'h-8 w-8 p-3',
        lg: 'h-[72px] w-[72px] p-4',
      },
      rounded: {
        default: 'rounded-lg',
        full: 'rounded-full',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  disabled?: boolean;
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant,
      size,
      iconSize,
      rounded,
      asChild = false,
      disabled = false,
      ...props
    },
    ref
  ) => {
    const Comp = asChild ? Slot : 'button';
    return (
      <Comp
        className={cn(
          buttonVariants({ variant, size, iconSize, rounded, className }),
          disabled && 'cursor-not-allowed pointer-events-none opacity-50'
        )}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = 'Button';

export { Button, buttonVariants };
