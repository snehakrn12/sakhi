import { useEffect, useRef, useState } from 'react';
import { cn, Streamer } from '../utils';

export function VoiceVisualizerBar({
  isDisabled,
  streamer,
  isSpeaking,
  maxWidth,
  width,
}: {
  isDisabled: boolean;
  streamer: Streamer | null;
  isSpeaking: boolean;
  maxWidth?: number;
  width?: number;
}) {
  const [volumeHistory, setVolumeHistory] = useState<number[]>([]);
  const [containerWidth, setContainerWidth] = useState(0);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastUpdateTime = useRef(Date.now());

  const [showLeftFade, setShowLeftFade] = useState(false);

  useEffect(() => {
    let animationFrameId: number;
    let source: MediaStreamAudioSourceNode | null = null;

    const setupAudioAnalysis = () => {
      if (streamer && streamer.audioContext && streamer.stream) {
        const analyser = streamer.audioContext.createAnalyser();
        analyser.fftSize = 256;
        analyserRef.current = analyser;

        source = streamer.audioContext.createMediaStreamSource(streamer.stream);
        source.connect(analyser);

        const dataArray = new Uint8Array(analyser.frequencyBinCount);

        const updateVolume = () => {
          if (isDisabled || !analyser) return;

          analyser.getByteFrequencyData(dataArray);
          const avgVolume =
            dataArray.reduce((a, b) => a + b, 0) / dataArray.length;

          const now = Date.now();
          if (now - lastUpdateTime.current >= 100) {
            lastUpdateTime.current = now;
            setVolumeHistory((prevHistory) => {
              const newHistory = [...prevHistory, avgVolume].slice(-barCount);
              return newHistory;
            });
          }

          animationFrameId = requestAnimationFrame(updateVolume);
        };

        updateVolume();
      }
    };

    if (isSpeaking) {
      setupAudioAnalysis();
    } else {
      // Clear volume history when not speaking
      setVolumeHistory([]);
    }

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
      if (source && analyserRef.current) {
        try {
          source.disconnect(analyserRef.current);
        } catch (error) {}
      }
    };
  }, [streamer, isDisabled, isSpeaking]);

  useEffect(() => {
    const updateContainerWidth = () => {
      if (containerRef.current) {
        const newWidth = containerRef.current.clientWidth;
        setContainerWidth(newWidth);
      }
    };

    updateContainerWidth();
    window.addEventListener('resize', updateContainerWidth);

    return () => {
      window.removeEventListener('resize', updateContainerWidth);
    };
  }, []);

  const barWidth = 4; // Fixed bar width
  const barGap = 2; // Fixed gap between bars
  const maxHeight = 25; // Half of the total height, as bars will extend both ways
  const totalHeight = maxHeight * 2;
  const cornerRadius = 2;
  const minHeightForRounding = 1; // Minimum height for applying rounded corners
  const minBarHeight = 1; // New constant for minimum bar height

  // Calculate number of bars based on container width
  const totalWidth = width || containerWidth || 0;
  const barCount = Math.floor((totalWidth + barGap) / (barWidth + barGap));

  // Determine if we should show the left fade
  useEffect(() => {
    setShowLeftFade(volumeHistory.length >= barCount);
  }, [volumeHistory, containerWidth]);

  // Function to map volume to bar height with increased sensitivity
  const getBarHeight = (volume: number) => {
    const sensitivity = 2; // Adjust this value to change sensitivity
    const normalizedVolume = Math.pow(volume / 255, 1 / sensitivity);
    return Math.max(
      minBarHeight,
      Math.min(normalizedVolume * maxHeight, maxHeight)
    );
  };

  return (
    <div
      ref={containerRef}
      className={cn(
        'audio-visualizer w-full relative overflow-hidden',
        maxWidth ? `max-w-[${maxWidth}px]` : '',
        width ? `w-[${width}px]` : ''
      )}
    >
      <div className='relative'>
        <svg width={totalWidth} height={totalHeight} className='block'>
          {volumeHistory.map((volume, index) => {
            const barHeight = getBarHeight(volume);
            const useRounding = barHeight >= minHeightForRounding;
            const x = index * (barWidth + barGap);

            return (
              <g key={index} transform={`translate(${x}, ${maxHeight})`}>
                <path
                  d={
                    useRounding
                      ? `
                  M 0 ${-barHeight + cornerRadius}
                  Q 0 ${-barHeight} ${cornerRadius} ${-barHeight}
                  H ${barWidth - cornerRadius}
                  Q ${barWidth} ${-barHeight} ${barWidth} ${
                          -barHeight + cornerRadius
                        }
                  V 0
                  H 0
                  Z
                `
                      : `
                  M 0 ${-barHeight}
                  H ${barWidth}
                  V 0
                  H 0
                  Z
                `
                  }
                  fill={isDisabled ? 'gray' : '#d1d1d1'}
                />
                <path
                  d={
                    useRounding
                      ? `
                  M 0 ${barHeight - cornerRadius}
                  Q 0 ${barHeight} ${cornerRadius} ${barHeight}
                  H ${barWidth - cornerRadius}
                  Q ${barWidth} ${barHeight} ${barWidth} ${
                          barHeight - cornerRadius
                        }
                  V 0
                  H 0
                  Z
                `
                      : `
                  M 0 ${barHeight}
                  H ${barWidth}
                  V 0
                  H 0
                  Z
                `
                  }
                  fill={isDisabled ? 'gray' : '#d1d1d1'}
                />
              </g>
            );
          })}
        </svg>
        <div
          className={`absolute inset-y-0 left-0 w-12 bg-gradient-to-r from-white to-transparent pointer-events-none transition-opacity duration-300 ease-in-out ${
            showLeftFade ? 'opacity-100' : 'opacity-0'
          }`}
        ></div>
        <div className='absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-white to-transparent pointer-events-none'></div>
      </div>
    </div>
  );
}
