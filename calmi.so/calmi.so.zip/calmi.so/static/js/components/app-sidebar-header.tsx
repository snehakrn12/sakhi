import { cn } from '../utils';
import { SidebarTrigger } from './ui/sidebar';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';

interface AppSidebarHeaderProps {
  headerPageTitle: string | null;
  pathname: string;
}

export const AppSidebarHeader = ({
  headerPageTitle,
  pathname,
}: AppSidebarHeaderProps) => {
  return (
    <header
      className={cn(
        'sticky top-0 z-[1] grid grid-cols-[auto,1fr] gap-y-4 shrink-0 items-center bg-background p-4 pb-0'
      )}
    >
      <SidebarTrigger className='-ml-1 w-12 h-12' />

      {headerPageTitle && (
        <>
          <p className='w-full text-right text-2xl font-semibold md:text-center md:pr-6'>
            {headerPageTitle}
          </p>

          {pathname === '/profile' && (
            <Tabs
              defaultValue='overview'
              className='w-full col-span-2 md:mx-auto md:max-w-[620px]'
            >
              <TabsList>
                <TabsTrigger value='overview'>overview</TabsTrigger>
                <TabsTrigger value='history'>history</TabsTrigger>
              </TabsList>
            </Tabs>
          )}
          <div className='w-full col-span-2 h-[1px] bg-zinc-400'></div>
        </>
      )}
    </header>
  );
};
