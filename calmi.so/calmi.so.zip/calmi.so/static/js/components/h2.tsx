interface H2Props {
  headline: string;
}

export const H2 = ({ headline }: H2Props) => {
  return (
    <h2 className='text-center font-bold text-2xl md:text-3xl 2xl:text-4xl'>
      {headline}
    </h2>
  );
};
