import { Link } from 'react-router-dom';
import {
  AUTH_QUERY_PARAM_SIGN_IN,
  AUTH_QUERY_PARAM_SIGN_UP,
  AUTH_ROUTE_PARAM,
  AUTH_VIEW_QUERY_PARAM,
  FEATURES,
} from '../constants';
import { CalmiLogo } from './calmi-logo';
import { FAQ } from './faq';
import { FeatureCard } from './feature-card';
import { H2 } from './h2';
import { Partners } from './partners';
import { Testimonials } from './testimonials';
import { Button } from './ui/button';
import VideoPlayer from './video-player';

const FAQ_ITEMS = [
  {
    headline: 'what is calmi?',
    description:
      'calmi is a speech-to-speech ai mental health companion designed to make mental health support more accessible. traditional therapy can have long wait times, high costs, and the hassle of finding the right therapist. with calmi, you get immediate access to an empathetic ai voice that offers emotional support anytime you need it.',
  },
  {
    headline: 'how does calmi work?',
    description:
      'calmi uses advanced ai models to simulate natural conversations. you simply talk to the app, and it responds in real time, helping you process emotions or work through challenges.',
  },
  {
    headline: 'is there a free plan?',
    description:
      'yes! the free plan offers 3 therapy sessions per month so you can explore the platform. if you need more, the plus plan gives you unlimited access.',
  },
  {
    headline: 'what is included in the plus plan?',
    description:
      "the plus plan offers unlimited therapy sessions, access to temporary chats, priority customer support, and early access to new features. it's perfect for those who want continuous support.",
  },
  {
    headline: 'can I cancel my subscription?',
    description:
      'yes, you can cancel anytime without fees. just go to settings, select "account," and manage your subscription. you\'ll retain access to paid features until the end of your billing period.',
  },
  {
    headline: 'is calmi a replacement for traditional therapy?',
    description:
      "calmi provides emotional support and complements traditional therapy, but it's not a replacement for professional care, especially for severe mental health conditions.",
  },
  {
    headline: 'what payment methods do you accept?',
    description:
      'we accept most major credit and debit cards through a secure payment processor for easy transactions.',
  },
  {
    headline: 'is my data secure and confidential?',
    description:
      'yes. we store session data securely in supabase using a vector database, which helps make the ai smarter and more responsive. all data is encrypted and managed in accordance with gdpr, a global privacy standard. if you request deletion, your data will be permanently removed from our system.',
  },
  {
    headline: 'does calmi support multiple languages?',
    description:
      "currently, calmi is available in english, but we're working on adding more languages to make mental health support accessible to everyone.",
  },
];

export default function home() {
  const videoSources = [
    {
      src: '/videos/intro-v2.mp4',
      type: 'video/mp4',
    },
  ];

  const authRouteBaseView = `/${AUTH_ROUTE_PARAM}?${AUTH_VIEW_QUERY_PARAM}=`;
  const signUpLink = `${authRouteBaseView}${AUTH_QUERY_PARAM_SIGN_UP}`;
  const signInLink = `${authRouteBaseView}${AUTH_QUERY_PARAM_SIGN_IN}`;

  return (
    <div className='px-4 sm:px-8 md:px-12 lg:px-16 xl:px-20 max-w-7xl mx-auto'>
      <div className='flex justify-between items-center py-4 sm:py-6 md:py-8 lg:py-10 bg-white'>
        <CalmiLogo />
        <div className='flex items-center space-x-2 sm:space-x-4'>
          <Button asChild variant='secondary' size='sm'>
            <Link to={signInLink}>log in</Link>
          </Button>
          <Button asChild variant='primary' size='sm'>
            <Link to={signUpLink}>sign up</Link>
          </Button>
        </div>
      </div>
      <div className='py-4 sm:py-6 md:py-8 mt-2 sm:mt-3 flex flex-col items-center sm:items-start'>
        <div className='main-text max-w-full sm:max-w-xl md:max-w-2xl'>
          <h1 className='text-3xl sm:text-4xl md:text-5xl lg:text-6xl mb-3 sm:mb-4 leading-tight text-left sm:text-left'>
            <span className='font-semibold font-sans'>
              talk through your problems with
            </span>{' '}
            <span className='font-bold font-sans'>ease.</span>
          </h1>
          <p className='text-base sm:text-lg md:text-xl mb-4 sm:mb-6 font-medium text-left sm:text-left font-sans'>
            no high fees, no wait times, no downloads, no hassle- just therapy
            with an empathetic AI whenever and wherever you need it.
          </p>
          <div className='flex justify-start sm:justify-start'>
            <Button asChild variant='primary' size='md'>
              <Link to={signUpLink}>connect now</Link>
            </Button>
          </div>
        </div>
      </div>

      <div className='shadow-2xl rounded-2xl'>
        <VideoPlayer
          videoSources={videoSources}
          posterImage='/images/intro-poster.webp'
          autoplay
          muted
          loop
          className='rounded-2xl'
        />
      </div>

      <div className='mt-14'>
        <Partners />
      </div>

      <div className='grid gap-4 mt-20 md:gap-8 md:mt-32'>
        <div>
          <H2 headline='all the good stuff' />{' '}
        </div>
        <section className='grid gap-8'>
          {FEATURES.map((feature, index) => {
            return <FeatureCard key={index} feature={feature} />;
          })}
        </section>
      </div>

      <div className='grid gap-4 mt-20 md:gap-8 md:mt-24'>
        <H2 headline='join 50,000+ for real support' />
        <Testimonials />
      </div>

      <div className='grid gap-4 mt-20 md:gap-8 md:mt-24'>
        <H2 headline='frequently asked questions' />
        <FAQ faqItems={FAQ_ITEMS} />
      </div>

      <div className='cta-section py-20 sm:py-24 text-center'>
        <div className='container mx-auto px-4 sm:px-6 md:px-8'>
          <H2 headline='get started for free' />
          <p className='text-m sm:text-m mb-6 sm:mb-8'>
            be heard. be understood. be better.
          </p>
          <Button asChild variant='primary' size='lg'>
            <Link to={signUpLink}>try calmi free</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
