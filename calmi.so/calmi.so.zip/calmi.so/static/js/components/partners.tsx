import { useEffect, useState } from 'react';
import { DUPLICATED_PARTNERS, PARTNERS } from '../constants';
import { PartnerItem } from './partner-item';

export const Partners = () => {
  const [isAnimated, setIsAnimated] = useState(false);

  const addAnimation = () => {
    setIsAnimated(true);
  };

  useEffect(() => {
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      addAnimation();
    }
  }, []);

  return (
    <article className='flex items-center overflow-hidden'>
      <ul
        className='animated-moving partners lg:hidden'
        data-animated={isAnimated}
        data-direction='left'
        data-duration='medium'
        style={{ '--_animation-duration': '60s' } as React.CSSProperties}
      >
        <div className='inner-scroller max-h-12'>
          {DUPLICATED_PARTNERS.map((partner, index) => (
            <PartnerItem key={index} partner={partner} />
          ))}
        </div>
      </ul>

      <ul className='hidden w-full max-h-12 lg:flex items-center justify-between'>
        {PARTNERS.map((partner, index) => (
          <PartnerItem key={index} partner={partner} />
        ))}
      </ul>
    </article>
  );
};
