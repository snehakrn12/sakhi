import { VIEWS } from '@supabase/auth-ui-shared';
import { AUTH_CONFIG } from '../constants/auth.constants';
import { supabase } from '../supabaseClient';
import {
  EmailAuth,
  EmailAuthProps,
  ForgottenPassword,
  ResetPassword,
  UpdatePassword,
} from './auth/interfaces';

interface AuthFormProps {
  authView: string;
  emailProp: Omit<EmailAuthProps, 'authView' | 'id'>;
}

export const AuthForm = ({ authView, emailProp }: AuthFormProps) => {
  switch (authView) {
    case VIEWS.SIGN_IN:
      return (
        <EmailAuth
          {...emailProp}
          authView='sign_in'
          redirectTo={AUTH_CONFIG.redirectTo}
          showLinks={VIEWS.SIGN_IN === authView}
          i18n={emailProp.i18n}
        />
      );
    case VIEWS.SIGN_UP:
      return (
        <EmailAuth
          {...emailProp}
          authView='sign_up'
          redirectTo={AUTH_CONFIG.redirectTo}
          showLinks={VIEWS.SIGN_UP === authView}
          i18n={emailProp.i18n}
        />
      );
    case VIEWS.FORGOTTEN_PASSWORD:
      return (
        <ForgottenPassword
          supabaseClient={supabase}
          setAuthView={emailProp.setAuthView}
          redirectTo={AUTH_CONFIG.redirectTo}
          showLinks={VIEWS.FORGOTTEN_PASSWORD === authView}
          i18n={emailProp.i18n}
        />
      );
    case VIEWS.UPDATE_PASSWORD:
      return <UpdatePassword supabaseClient={supabase} i18n={emailProp.i18n} />;
    case VIEWS.RESET_PASSWORD:
      return <ResetPassword supabaseClient={supabase} />;
    default:
      return null;
  }
};
