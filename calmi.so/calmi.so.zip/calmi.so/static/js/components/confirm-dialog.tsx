import { Loader2 } from 'lucide-react';
import { Dispatch, ReactNode, SetStateAction } from 'react';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { Button } from './ui/button';

interface ConfirmDialogProps {
  description?: string;
  confirmButtonText?: string;
  cancelButtonText?: string;
  confirmButtonColor?: 'primary' | 'destructive' | 'dangerOutline';
  headline?: string;
  loading?: boolean;
  open?: boolean;
  children?: ReactNode;
  handleConfirm: () => void;
  onOpenChange?: Dispatch<SetStateAction<boolean>>;
}

export const ConfirmDialog = ({
  confirmButtonText = 'confirm',
  cancelButtonText = 'cancel',
  confirmButtonColor = 'primary',
  headline,
  description,
  loading,
  open,
  children,
  handleConfirm,
  onOpenChange,
}: ConfirmDialogProps) => {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      {/* <AlertDialogTrigger asChild>
          <Button className='mt-4 w-auto px-6 rounded-md border-none bg-[#FFC700] hover:bg-[#FFB900] text-[#1E1E1E] font-bold font-mono outline-none'>
            {triggerButtonText}
          </Button>
        </AlertDialogTrigger> */}

      <AlertDialogContent className='max-w-[90%] rounded-lg md:max-w-md'>
        <AlertDialogHeader>
          {headline && (
            <AlertDialogTitle className='text-lg'>{headline}</AlertDialogTitle>
          )}

          {description && (
            <AlertDialogDescription className='text-base'>
              {description}
            </AlertDialogDescription>
          )}
        </AlertDialogHeader>

        {children}
        <AlertDialogFooter className='flex-row justify-between items-center mt-8'>
          <AlertDialogCancel className='h-10 text-base m-0'>
            {cancelButtonText}
          </AlertDialogCancel>
          {/* TODO(VN): Add loading */}
          {/* TODO(VN): Add md size button = 40px height */}
          <Button
            className='text-base h-10'
            variant={confirmButtonColor}
            onClick={() => {
              handleConfirm();
              onOpenChange?.(false);
            }}
          >
            {loading ? (
              <Loader2 className='h-4 w-4 animate-spin' />
            ) : (
              <span>{confirmButtonText}</span>
            )}
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
