import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';

interface FAQProps {
  faqItems: {
    headline: string;
    description: string;
  }[];
}

export const FAQ = ({ faqItems }: FAQProps) => {
  return (
    <Accordion
      type='single'
      collapsible
      className='w-full max-w-2xl mx-auto px-4 sm:px-0'
    >
      {faqItems.map((faqItem, index) => (
        <AccordionItem value={`item-${index + 1}`} key={index}>
          <AccordionTrigger className='text-left text-lg font-medium'>
            {faqItem.headline}
          </AccordionTrigger>
          <AccordionContent className='text-sm text-left'>
            {faqItem.description}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
};
