import React, { useEffect, useRef, useState } from 'react';
import { cn } from '../utils';

interface VideoPlayerProps {
  videoSources: {
    src: string;
    type: string;
  }[];
  posterImage?: string;
  autoplay?: boolean;
  muted?: boolean;
  loop?: boolean;
  className?: string;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({
  videoSources,
  posterImage,
  autoplay = true,
  muted = true,
  loop = true,
  className,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isIntersecting, setIsIntersecting] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    const options = {
      root: null,
      rootMargin: '50px',
      threshold: 0.1,
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        setIsIntersecting(entry.isIntersecting);

        if (!video) return;

        // If video is intersecting and hasn't loaded yet, start loading
        if (entry.isIntersecting && !isLoaded && video) {
          video.load();
          setIsLoaded(true);
        }

        // Play/pause based on visibility
        if (entry.isIntersecting && video.paused) {
          video.play().catch(() => {
            // Ignore play() errors since they're expected when navigating away
          });
        } else if (!entry.isIntersecting && !video.paused) {
          video.pause();
        }
      });
    }, options);

    if (video) {
      observer.observe(video);
    }

    return () => {
      if (video) {
        video.pause();
        video.currentTime = 0;
        observer.unobserve(video);
      }
    };
  }, [isLoaded]);

  return (
    <div className='w-full relative'>
      <video
        ref={videoRef}
        className={cn('w-full h-auto', className)}
        poster={posterImage}
        autoPlay={autoplay && isIntersecting}
        muted={muted}
        loop={loop}
        playsInline
        preload='metadata'
      >
        {videoSources.map((source, index) => (
          <source key={index} src={source.src} type={source.type} />
        ))}
      </video>
    </div>
  );
};

export default VideoPlayer;
