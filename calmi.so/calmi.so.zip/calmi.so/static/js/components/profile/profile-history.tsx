import { MessageHistory } from '../../components/logs';
import { useApi } from '../../hooks';

export const ProfileHistory = ({ isSubscribed }: { isSubscribed: boolean }) => {
  const { data: messageHistory, isLoading: isLoadingMessageHistory } = useApi<
    {
      role: 'user' | 'ai';
      message: string;
    }[]
  >('messageHistory', '/message-history', {
    secure: true,
    queryParams: { limit: isSubscribed ? 50 : 20 },
  });

  return (
    <div className='mt-6 w-full max-w-96 md:mx-auto md:max-w-[620px]'>
      <MessageHistory
        messageHistory={messageHistory ?? []}
        loading={isLoadingMessageHistory}
      />
    </div>
  );
};
