import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { Info, NotebookText } from 'lucide-react';
import { Link } from 'react-router-dom';
import { toast } from '../../hooks';
import { useAuthContext } from '../../providers';
import { TherapyProfile } from '../../types';
import { FeedbackForm } from '../feedback-form';
import { ProfileOverviewSkeleton } from '../profile-overview-skeleton';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';

interface TherapyProfileOverviewResponse {
  category: string;
  text: string;
}

interface ParsedTherapyProfileDetails extends Omit<TherapyProfile, 'overview'> {
  overview: TherapyProfileOverviewResponse[];
}

export const ProfileOverview = () => {
  const { session } = useAuthContext();

  const { data: therapyProfile, isLoading } = useQuery({
    queryKey: ['therapyProfile'],
    queryFn: async () => {
      if (!session) {
        toast({
          title: 'whoops!',
          description: `an error occurred while fetching your therapy profile, try again or contact support.`,
          variant: 'destructive',
        });

        return null;
      }

      const { data: therapyProfile } = await axios.get(
        `${process.env.REACT_APP_API_URL}/therapy-profile`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      if (!therapyProfile || !therapyProfile.overview) {
        toast({
          title: 'whoops!',
          description: `an error occurred while fetching your therapy profile, try again or contact support.`,
          variant: 'destructive',
        });

        return null;
      }

      return {
        ...therapyProfile,
        overview: JSON.parse(therapyProfile.overview),
      } as ParsedTherapyProfileDetails;
    },
    retry: false,
  });

  return (
    <div className='mt-6 lowercase'>
      {isLoading ? (
        <ProfileOverviewSkeleton />
      ) : therapyProfile ? (
        <div>
          <div className='w-full flex items-center justify-between gap-2 font-semibold text-xl'>
            <div className='flex items-center gap-2'>
              <NotebookText />
              <p>how it's going</p>
              <Badge className='mt-1' variant='outline'>
                beta
              </Badge>
            </div>

            <FeedbackForm showTitle={false} />
          </div>

          <div className='grid gap-4 mt-2 p-3'>
            {therapyProfile.overview.map((overview, index) => (
              <div className='grid gap-1' key={index}>
                <p className='text-lg font-semibold'>{overview.category}</p>
                <p>{overview.text}</p>
              </div>
            ))}
          </div>

          {/* TODO: Add info to do more sessions to extend profile when only 2 sessions are completed */}
        </div>
      ) : (
        <div className='p-3 grid gap-2 justify-items-center text-sm bg-gray-100 rounded-xl font-medium text-center'>
          <Info className='w-5 h-5' />
          <p>
            looks like your profile isn't ready yet!
            <br /> complete 2 sessions and we'll cook up your personalized
            profile
          </p>

          <Button
            className='mt-4 max-w-min'
            asChild
            size='sm'
            variant='primary'
          >
            <Link to='/'>begin session</Link>
          </Button>
        </div>
      )}
    </div>
  );
};
