import { Skeleton } from './ui/skeleton';

export const ProfileOverviewSkeleton = () => {
  return (
    <div>
      <div className='w-full h-9 flex items-center justify-between gap-2 font-semibold text-xl'>
        <div className='flex items-center gap-2'>
          <Skeleton className='w-5 h-5' />
          <Skeleton className='h-6 w-32' />
          <Skeleton className='h-5 w-12 mt-1' />
        </div>
        <Skeleton className='h-8 w-8' />
      </div>

      <div className='grid gap-4 mt-2 p-3'>
        {[1, 2, 3, 4, 5].map((_, index) => (
          <div className='grid gap-2' key={index}>
            <Skeleton className='h-7 w-48' />
            <Skeleton className='h-4 mt-1 w-full' />
            <Skeleton className='h-4 w-full sm:w-80' />
            <Skeleton className='sm:hidden h-4 w-24' />
          </div>
        ))}
      </div>
    </div>
  );
};
