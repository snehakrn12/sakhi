import { Check } from 'lucide-react';
import { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '../ui/card';

export const PricingCard = ({
  title,
  icon,
  description,
  planLink,
  buttonVariant,
  perkList,
  userEmail,
  price,
  buttonText,
}: {
  title: string;
  icon: ReactNode;
  description: string;
  planLink: string;
  buttonVariant: 'outline' | 'primary';
  perkList: (string | ReactNode)[];
  userEmail: string | null;
  price: string;
  buttonText: string;
}) => {
  const navigate = useNavigate();

  return (
    <Card className='sm:rounded-l-none sm:h-96'>
      <CardHeader>
        <CardTitle className='flex items-center gap-2'>
          {icon} {title}
        </CardTitle>
        <CardDescription className='text-sm h-12'>
          {description}
        </CardDescription>
        <div className='flex items-baseline mt-2'>
          <span className='text-4xl font-bold'>${price}</span>
          <span className='text-sm ml-1'>/month</span>
        </div>
      </CardHeader>
      <CardFooter>
        <Button asChild className='w-full rounded-full' variant={buttonVariant}>
          <a
            rel='noreferrer'
            target='_blank'
            href={planLink + '?prefilled_email=' + userEmail}
            onClick={() => navigate('/')}
          >
            {buttonText}
          </a>
        </Button>
      </CardFooter>
      <CardContent>
        <ul className='grid gap-1'>
          {perkList.map((perk, index) => (
            <li className='flex items-center' key={index}>
              <Check className='mr-2 h-3 w-3 text-black' />
              <div className='text-sm font-medium'>{perk}</div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};
