import { useEffect, useRef } from 'react';
import { Playback } from '../utils';

interface AudioVisualizerProps {
  playback: Playback | null;
}

export const AudioVisualizer = ({ playback }: AudioVisualizerProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    let animationFrameNumber: number | null = null;

    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    if (!ctx) return;

    const animate = (time: number) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Base radius (increased from 40 to 80)
      let radius = 100;

      if (playback && playback.analyser) {
        const bufferLength = playback.analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        playback.analyser.getByteFrequencyData(dataArray);

        const average = dataArray.reduce((a, b) => a + b) / bufferLength;
        // Amplify the effect (increased from 20 to 50)
        radius += (average / 256) * 30;
      }

      // Add a subtle continuous pulsation
      const pulsation = Math.sin(timeRef.current * 0.003) * 1;
      radius += pulsation;

      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2, radius, 0, 2 * Math.PI);
      ctx.fillStyle = '#FFC700';
      ctx.fill();

      timeRef.current = time;

      animationFrameNumber = requestAnimationFrame(animate);
    };

    animate(0);

    return () => {
      if (!animationFrameNumber) return;

      return cancelAnimationFrame(animationFrameNumber);
    };
  }, [playback]);

  return (
    <div className="'pointer-events-none'">
      <canvas
        ref={canvasRef}
        width={250}
        height={250}
        style={{ maxWidth: '100%', height: 'auto' }}
      />
    </div>
  );
};
