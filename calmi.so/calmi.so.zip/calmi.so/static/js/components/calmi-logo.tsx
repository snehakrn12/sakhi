import { Link } from 'react-router-dom';
import { cn } from '../utils';

interface CalmiLogoProps {
  variant?: 'default' | 'small';
  className?: string;
}

export const CalmiLogo = ({
  variant = 'default',
  className,
}: CalmiLogoProps) => {
  const size = variant === 'small' ? 'text-[24px]' : 'text-[32px]';

  return (
    <Link
      title='calmi logo'
      to='/'
      className={cn('font-black font-sans outline-none', size, className)}
    >
      calmi
    </Link>
  );
};
