import { Session as AuthSession } from '@supabase/supabase-js';
import { ReactNode, useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  AUDIO_CONTEXT_SETTINGS,
  CLEAR_BUFFER_TOKEN,
  INTERRUPT_TOKEN,
  PROCESSING_LONG_AUDIO_TOKEN,
  SERVER_WS_URL,
  START_LISTENING_TOKEN,
} from '../constants';
import { toast, useSessionSummary } from '../hooks';
import { useLogs } from '../hooks/use-logs';
import { SessionConnectionStatus, SubscriptionPlan } from '../types';
import {
  getSessionDurationLimit,
  Playback,
  saveMessageToMessageHistory,
  Streamer,
} from '../utils';
import { AnimatedMessage } from './animated-message';
import { AudioVisualizer } from './audio-visualizer';
import { SessionButtons } from './session-buttons';
import { SessionInfoDialog } from './session-info-dialog';
import { Button } from './ui/button';
import { ToastAction } from './ui/toast';
import { VoiceVisualizerBar } from './voice-visualizer-bar';

export default function Session({
  isGenZMode,
  handleSessionCount,
  handleIsRecording,
  sessionCountLimitReached,
  isSubscribed,
  userId,
  session,
  subscriptionPlan,
}: {
  handleSessionCount: () => void;
  handleIsRecording: (isRecording: boolean) => boolean;
  isGenZMode: boolean;
  sessionCountLimitReached: boolean;
  userId: string | null;
  isSubscribed: boolean;
  session: AuthSession | null;
  subscriptionPlan: SubscriptionPlan | null;
}) {
  const ws = useRef<WebSocket | null>(null);
  const streamer = useRef<Streamer | null>(null);
  const playback = useRef<Playback | null>(null);
  const lastEOS = useRef<Date | null>(null);
  const beginSessionButtonRef = useRef<HTMLButtonElement>(null);
  const textInputRef = useRef<HTMLInputElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [connectionStatus, setConnectionStatus] =
    useState<SessionConnectionStatus>(null);
  const [showRemainingTimeDuration, setShowRemainingTimeDuration] =
    useState(false);
  const [showAnimatedMessage, setShowAnimatedMessage] = useState(false);
  const [sessionDuration, setSessionDuration] = useState(0);

  const { assistantMessage, logMessage, clearLogs } = useLogs({
    isSubscribed: false,
  });
  const { startSession, endSession, resetLastActivity } =
    useSessionSummary(userId);
  const navigate = useNavigate();

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }

      if (ws.current) {
        ws.current.close();
        ws.current = null;
      }

      if (streamer.current) {
        streamer.current.stop(true);
      }

      if (playback.current) {
        playback.current.stop(true);
      }

      endSession(sessionDuration);
      clearLogs();
    };
  }, []);

  const handleSpeakButtonToggle = () => {
    resetLastActivity();

    if (!isRecording) return;

    if (isSpeaking) {
      streamer.current?.endSpeech();
    } else {
      streamer.current?.startSpeech();
      setConnectionStatus('listening...');
    }

    setIsSpeaking((prevState) => !prevState);
  };

  const showEndSessionNotification = () => {
    toast({
      title: 'session ended',
      action: (
        <ToastAction
          altText='goto profile page'
          onClick={() => navigate('/profile?tab=history')}
        >
          view history
        </ToastAction>
      ),
    });
  };

  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      const isTextInputFocused =
        document.activeElement === textInputRef.current;

      if (event.key === 'Enter' && isRecording && !isTextInputFocused) {
        event.preventDefault();
        handleSpeakButtonToggle();
      }
    };

    window.addEventListener('keydown', handleKeyPress);

    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [isRecording, isSpeaking]);

  const stopRecording = ({
    graceful = false,
    isError = false,
    errorTitle = 'whoops',
    errorMessage = 'looks like an error occurred. give it another shot.',
  }: {
    graceful?: boolean;
    isError?: boolean;
    errorTitle?: string;
    errorMessage?: string | ReactNode;
  } = {}) => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    if (isError) {
      toast({
        title: errorTitle,
        description: errorMessage,
      });
    } else {
      handleSessionCount();
      showEndSessionNotification();
    }

    clearLogs();
    setSessionDuration(0);
    setShowRemainingTimeDuration(false);
    handleIsRecording(false);
    setIsRecording(false);
    setIsSpeaking(false);
    streamer.current?.stop(graceful);
    playback.current?.stop(graceful);
    setConnectionStatus(null);
    ws.current?.close();
    ws.current = null;
    lastEOS.current = null;
    endSession(sessionDuration);
  };

  const startRecording = async () => {
    const sessionId = await startSession();
    if (!sessionId) return;

    const durationLimit = getSessionDurationLimit(
      isSubscribed,
      subscriptionPlan
    );
    let warningShown = false;

    timerRef.current = setInterval(() => {
      setSessionDuration((prev) => {
        const newDuration = prev + 1000;

        // Show warning when last minute starts
        if (newDuration === durationLimit - 60000 && !warningShown) {
          warningShown = true;
          setShowRemainingTimeDuration(true);
          // Move toast outside of render cycle
          setTimeout(() => {
            toast({
              title: "time's almost up!",
              description:
                '1 min left on this session rn - no worries tho, you can restart right after',
              variant: 'destructive',
            });
          }, 0);
        }

        // End session when time is up
        if (newDuration >= durationLimit) {
          // Move stopRecording call outside of render cycle
          setTimeout(() => {
            stopRecording({
              graceful: true,
              isError: true,
              errorTitle: 'session duration limit reached',
              errorMessage:
                'your session has ended. feel free to start a new one!',
            });
          }, 0);
        }

        return newDuration;
      });
    }, 1000);

    setIsRecording(true);
    handleIsRecording(true);

    let initialMessageCount = 0;

    if (beginSessionButtonRef.current) {
      beginSessionButtonRef.current.blur();
    }

    if (!ws.current || ws.current.readyState !== WebSocket.OPEN) {
      if (!session) {
        stopRecording({
          graceful: true,
          isError: true,
          errorTitle: 'authorization error',
          errorMessage: 'pls sign in to start a session.',
        });
        return;
      }

      const authToken = session.access_token;

      ws.current = new WebSocket(
        `${SERVER_WS_URL}?isGenZ=${isGenZMode}&token=${authToken}`
      );

      if (initialMessageCount === 0) {
        setConnectionStatus('connecting...');
      }

      ws.current.binaryType = 'arraybuffer';
      ws.current.onopen = () => {
        setConnectionStatus('connecting...');

        ws.current &&
          (ws.current.onmessage = async (event) => {
            if (event.data instanceof ArrayBuffer) {
              // Handle audio data
              playback.current?.addSamples(new Float32Array(event.data));

              if (initialMessageCount > 1) {
                setConnectionStatus('');
              }
            } else {
              // Handle text messages
              const messageData = event.data;

              if (messageData === CLEAR_BUFFER_TOKEN) {
                playback.current?.clear().then((didInterrupt: boolean) => {
                  if (didInterrupt) {
                    ws.current && ws.current.send(INTERRUPT_TOKEN);
                  }
                });
              } else if (messageData === START_LISTENING_TOKEN) {
                playback.current?.once('playbackEnd', () => {
                  setConnectionStatus('your turn');
                });
              } else if (messageData === PROCESSING_LONG_AUDIO_TOKEN) {
                setConnectionStatus('processing longer message...');
              } else {
                try {
                  const parsedMessage = messageData.startsWith('{')
                    ? JSON.parse(messageData)
                    : { type: 'text', content: messageData };

                  if (parsedMessage.type === 'error') {
                    setConnectionStatus('your turn');
                    toast({
                      title: "whoops! didn't catch that",
                      description: parsedMessage.content.toLowerCase(),
                      variant: 'destructive',
                    });
                    streamer.current?.handleError();
                    setIsSpeaking(false);
                    setShowAnimatedMessage(false);
                    return;
                  }

                  if (parsedMessage.type === 'text') {
                    clearLogs();
                    logMessage({ message: parsedMessage.content });
                    setIsRecording(true);
                    setShowAnimatedMessage(true);
                  }
                } catch (error) {
                  toast({
                    title: 'whoops!',
                    description:
                      'looks like an error occurred. give it another shot.',
                    variant: 'destructive',
                  });
                  return;
                }

                if (initialMessageCount < 1) {
                  setConnectionStatus('connecting...');
                } else {
                  setTimeout(() => {
                    setConnectionStatus('');
                  }, 500);
                }

                if (!userId) return;

                if (initialMessageCount > 0) {
                  const eventMessage = event.data;

                  if (
                    typeof eventMessage !== 'string' ||
                    eventMessage.length === 0
                  )
                    return;

                  // Add message to message history
                  await saveMessageToMessageHistory(
                    userId,
                    sessionId,
                    event.data
                  );
                }

                initialMessageCount += 1;
              }
            }
          });

        playback.current = new Playback(
          new AudioContext(AUDIO_CONTEXT_SETTINGS),
          isMuted
        );

        playback.current.on('playbackStart', () => {
          setShowAnimatedMessage(true);

          if (!lastEOS.current) {
            return;
          }
        });

        playback.current.on('playbackEnd', () => {
          if (initialMessageCount >= 1) {
            setConnectionStatus('your turn');
          }
        });

        playback.current.start();
        streamer.current = new Streamer(ws.current!, logMessage);

        streamer.current.on('speechStart', () => {
          playback.current?.clear().then((didInterrupt: boolean) => {
            if (didInterrupt) {
              ws.current && ws.current.send(INTERRUPT_TOKEN);
            }
          });
        });

        streamer.current.on('speechEnd', () => {
          lastEOS.current = new Date();

          setConnectionStatus('thinking...');
        });

        try {
          // Check if the user has granted microphone access
          streamer.current.start().catch((error) => {
            if (
              error instanceof DOMException &&
              error.name === 'NotAllowedError'
            ) {
              if (ws.current) {
                ws.current.onclose = null;
                ws.current.close(1000);
              }
              stopRecording({
                graceful: true,
                isError: true,
                errorTitle: 'oops! mic access denied',
                errorMessage: (
                  <>
                    hey! we need your mic to chat.
                    <br />
                    <br />
                    <span className='font-bold'>1.</span> find mic permissions
                    <br />
                    <span className='font-bold'>2.</span> set mic to "ask" or
                    "allow" and we're good to go
                  </>
                ),
              });
            } else {
              stopRecording({ graceful: true, isError: true });
            }
          });
        } catch (error) {
          stopRecording({ graceful: true, isError: true });
          return;
        }

        ws.current &&
          (ws.current.onclose = (event) => {
            // if users navigated away, stop audio stream
            if (event.code === 1001) {
              stopRecording({ graceful: false, isError: false });
            }

            const isError = event.code !== 1005;
            stopRecording({ graceful: true, isError });
          });
      };

      if (initialMessageCount > 0) {
        setConnectionStatus(null);
      }

      ws.current.onerror = (event) => {
        stopRecording({ graceful: true, isError: true });
      };
    }
  };

  const toggleMute = () => {
    setIsMuted((prevMuted) => !prevMuted);
    if (playback.current) {
      playback.current.toggleMute();
    }
  };

  const limitReached =
    sessionCountLimitReached &&
    (!subscriptionPlan ||
      subscriptionPlan === 'free' ||
      subscriptionPlan === 'plus' ||
      subscriptionPlan === 'pro');

  const remainingTime = Math.ceil(
    (getSessionDurationLimit(isSubscribed, subscriptionPlan) -
      sessionDuration) /
      1000
  );

  return (
    <div className='relative h-full grid content-between pb-5 bg-white md:content-normal md:pb-[170px]'>
      <div>
        <div className='h-6'>
          {(connectionStatus || connectionStatus === '') &&
            !showRemainingTimeDuration && (
              <h2 className='font-semibold text-center'>
                <span>{connectionStatus}</span>
              </h2>
            )}

          {showRemainingTimeDuration && (
            <h2 className='font-semibold text-center'>
              <span>{remainingTime} sec left</span>
            </h2>
          )}
        </div>

        <div className='w-full max-w-3xl flex justify-center mx-auto mt-2'>
          <AudioVisualizer playback={playback.current} />
        </div>

        <div className='mt-4 max-w-md mx-auto overflow-hidden text-center'>
          {sessionCountLimitReached ? (
            <div className='grid gap-2'>
              <p className='font-semibold'>monthly limit reached.</p>

              {limitReached && subscriptionPlan !== 'pro' && (
                <Button
                  asChild
                  variant='outline'
                  size='sm'
                  className='max-w-fit justify-self-center pointer-events-auto'
                >
                  <Link to='/pricing' className='pointer-events-auto'>
                    {subscriptionPlan === 'plus' ? 'view plans' : 'upgrade'}
                  </Link>
                </Button>
              )}
            </div>
          ) : (
            <div className='h-16'>
              {isRecording && assistantMessage && showAnimatedMessage && (
                <AnimatedMessage message={assistantMessage} />
              )}
            </div>
          )}
        </div>
      </div>

      {/* TODO(VN): Only show visualizer when user starts to speak */}
      {!limitReached && (
        <div className='absolute inset-x-0 -bottom-28 max-w-[340px] grid gap-4 mx-auto'>
          <VoiceVisualizerBar
            maxWidth={448}
            width={340}
            isDisabled={limitReached}
            streamer={streamer.current}
            isSpeaking={isSpeaking}
          />

          <SessionButtons
            disabled={
              connectionStatus === 'connecting...' ||
              connectionStatus === 'thinking...' ||
              connectionStatus === ''
            }
            isSpeaking={isSpeaking}
            isRecording={isRecording}
            isMuted={isMuted}
            handleSpeakButtonToggle={handleSpeakButtonToggle}
            startRecording={startRecording}
            stopRecording={stopRecording}
            toggleMute={toggleMute}
          />
        </div>
      )}
      <SessionInfoDialog />
    </div>
  );
}
