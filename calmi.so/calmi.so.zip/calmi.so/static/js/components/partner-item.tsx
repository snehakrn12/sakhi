import { Partner } from '../types';

interface PartnerItemProps {
  partner: Partner;
}

export const PartnerItem = ({ partner }: PartnerItemProps) => {
  return (
    <li className='flex items-center'>
      {partner.link ? (
        <a
          href={partner.link}
          title={partner.linkTitle}
          target='_blank'
          rel='noopener noreferrer'
        >
          <img
            className={partner.className}
            alt={partner.alt}
            src={partner.src}
            loading='lazy'
          />
        </a>
      ) : (
        <img
          className={partner.className}
          alt={partner.alt}
          src={partner.src}
          loading='lazy'
        />
      )}
    </li>
  );
};
