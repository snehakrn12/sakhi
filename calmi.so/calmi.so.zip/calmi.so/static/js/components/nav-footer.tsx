'use client';

import { ArrowRightFromLine } from 'lucide-react';
import {
  FREE_SESSION_COUNT_LIMIT,
  PLUS_SESSION_COUNT_LIMIT,
  PRO_SESSION_COUNT_LIMIT,
} from '../constants';
import { SubscriptionPlan } from '../types';
import { SubscriptionStateNavInfo } from './subsctiption-state-nav-info';
import {
  SidebarGroup,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from './ui/sidebar';

export function NavFooter({
  handleLogout,
  isSubscribed,
  sessionCount,
  sessionCountLimitReached,
  subscriptionPlan,
}: {
  handleLogout: () => void;
  isSubscribed: boolean;
  subscriptionPlan: SubscriptionPlan;
  sessionCountLimitReached: boolean;
  sessionCount: number;
}) {
  const sessionCountLimit = () => {
    if (!isSubscribed) return FREE_SESSION_COUNT_LIMIT;

    if (subscriptionPlan === 'plus') {
      return PLUS_SESSION_COUNT_LIMIT;
    } else if (subscriptionPlan === 'pro') {
      return PRO_SESSION_COUNT_LIMIT;
    } else if (subscriptionPlan === 'unlimited') {
      return 1000000;
    }

    return FREE_SESSION_COUNT_LIMIT;
  };

  return (
    <SidebarGroup className='p-0'>
      <SidebarMenu>
        <SidebarMenuItem>
          <SidebarMenuButton onClick={handleLogout}>
            <ArrowRightFromLine className='h-4 w-4' />
            <span>log out</span>
          </SidebarMenuButton>
        </SidebarMenuItem>

        {subscriptionPlan !== 'unlimited' && (
          <div className='mt-2'>
            <SubscriptionStateNavInfo
              subscriptionPlan={subscriptionPlan}
              sessionCount={sessionCount}
              sessionCountLimit={sessionCountLimit()}
              sessionCountLimitReached={sessionCountLimitReached}
              isSubscribed={isSubscribed}
            />
          </div>
        )}
      </SidebarMenu>
    </SidebarGroup>
  );
}
