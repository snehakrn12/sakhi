import posthog from 'posthog-js';
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

interface PageLeaveTrackerProps {
  customProps?: Record<string, unknown>;
}

export const PostHogPageLeaveTracker = ({
  customProps,
}: PageLeaveTrackerProps) => {
  const location = useLocation();

  useEffect(() => {
    const capturePageLeave = () => {
      posthog.capture('$pageleave', {
        path: location.pathname,
        referrer: document.referrer,
        leaveTime: new Date().toISOString(),
        timeSpentSeconds: Math.floor(
          (Date.now() - window.performance.timing.navigationStart) / 1000
        ),
        visibilityState: document.visibilityState,
        ...customProps,
      });
    };

    window.addEventListener('beforeunload', capturePageLeave);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        capturePageLeave();
      }
    });

    return () => {
      window.removeEventListener('beforeunload', capturePageLeave);
      document.removeEventListener('visibilitychange', capturePageLeave);
    };
  }, [location, customProps]);

  return null;
};
