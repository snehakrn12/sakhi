import { ChevronDownIcon, ChevronUpIcon, InfoIcon } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CONSENT_COOKIE_NAME } from '../../constants';
import { CookiePreferences } from '../../types';
import { cn } from '../../utils';
import { AlertDialog, AlertDialogDescription } from '../ui/alert-dialog';
import { Button } from '../ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { Label } from '../ui/label';
import { Switch } from '../ui/switch';

interface CookieConsentProps {
  onAccept: () => void;
  onDecline?: () => void;
  privacyPolicyUrl: string;
  companyName: string;
}

export const CookieConsentDialog = ({
  onAccept,
  onDecline,
  privacyPolicyUrl,
  companyName,
}: CookieConsentProps) => {
  const [showConsent, setShowConsent] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [preferences, setPreferences] = useState<CookiePreferences>({
    necessary: true,
    analytics: false,
  });
  const [initialized, setInitialized] = useState(false);

  const getTimestamp = () => new Date().toISOString();

  useEffect(() => {
    if (!initialized) {
      const consentCookie = document.cookie
        .split('; ')
        .find((row) => row.startsWith(CONSENT_COOKIE_NAME));

      if (consentCookie) {
        try {
          const savedPreferences = JSON.parse(
            decodeURIComponent(consentCookie.split('=')[1])
          );
          setPreferences(savedPreferences.preferences);
          if (savedPreferences.preferences.analytics) {
            onAccept();
          }
          setShowConsent(false);
        } catch (e) {
          setShowConsent(true);
        }
      } else {
        setShowConsent(true);
      }
      setInitialized(true);
    }
  }, [initialized, onAccept]);

  const savePreferences = (newPreferences: CookiePreferences) => {
    const expiryDate = new Date();
    expiryDate.setFullYear(expiryDate.getFullYear() + 1);

    const cookieData = {
      preferences: newPreferences,
      lastUpdated: getTimestamp(),
      version: '1.0',
    };

    document.cookie = `${CONSENT_COOKIE_NAME}=${encodeURIComponent(
      JSON.stringify(cookieData)
    )};expires=${expiryDate.toUTCString()};path=/;SameSite=Lax;Secure`;
  };

  const handleAcceptAll = () => {
    const newPreferences = {
      ...preferences,
      analytics: true,
    };
    setPreferences(newPreferences);
    savePreferences(newPreferences);
    onAccept();
    handleClose();
  };

  const handleDeclineAll = () => {
    const newPreferences = {
      necessary: true,
      analytics: false,
    };
    setPreferences(newPreferences);
    savePreferences(newPreferences);
    onDecline?.();
    handleClose();
  };

  const handleSavePreferences = () => {
    savePreferences(preferences);
    if (preferences.analytics) {
      onAccept();
    } else {
      onDecline?.();
    }
    handleClose();
  };

  const handleClose = () => {
    setShowPreferences(false);
    setShowConsent(false);
  };

  const toggleAnalytics = () => {
    setPreferences((prev) => ({
      ...prev,
      analytics: !prev.analytics,
    }));
  };

  // Preference Dialog/Sheet Content
  const PreferenceContent = () => (
    <div className='lowercase'>
      <div className='space-y-4'>
        {/* Necessary Cookies */}
        <div className='flex items-start space-x-4 pt-4'>
          <Switch checked disabled />
          <div className='space-y-1'>
            <Label>necessary cookies</Label>
            <p className='text-sm text-muted-foreground'>
              required for the website to function properly. cannot be disabled.
            </p>
          </div>
        </div>

        {/* Analytics Cookies */}
        <div className='flex items-start space-x-4'>
          <Switch
            id='analytics'
            checked={preferences.analytics}
            onCheckedChange={toggleAnalytics}
          />
          <div className='space-y-1'>
            <Label htmlFor='analytics'>analytics cookies</Label>
            <p className='text-sm text-muted-foreground'>
              help us understand how visitors interact with our website using
              PostHog analytics.
            </p>
          </div>
        </div>

        {/* Details Section */}
        <div className='pt-4'>
          <Button
            variant='ghost'
            onClick={() => setShowDetails(!showDetails)}
            className='h-auto p-0 hover:bg-transparent'
          >
            <span className='flex items-center text-sm'>
              {showDetails ? (
                <ChevronUpIcon className='mr-1' size={16} />
              ) : (
                <ChevronDownIcon className='mr-1' size={16} />
              )}
              {showDetails ? 'Hide Details' : 'Show Details'}
            </span>
          </Button>

          {showDetails && (
            <div className='mt-3 space-y-4'>
              <AlertDialog>
                <AlertDialogDescription className='text-black'>
                  <div className='ml-2'>
                    <div className='grid grid-cols-[auto,1fr] gap-2'>
                      <InfoIcon className='h-4 w-4 mt-2' />
                      <p>
                        analytics cookies collect the following information:
                      </p>
                    </div>
                    <ul className='list-disc ml-6 mt-2'>
                      <li>pages visited and time spent</li>
                      <li>anonymous usage patterns</li>
                      <li>basic device information</li>
                      <li>approximate geographic location (country level)</li>
                    </ul>
                  </div>
                </AlertDialogDescription>
              </AlertDialog>
              <p className='text-sm text-muted-foreground'>
                we use PostHog analytics, which processes data within the eu.
                data is retained for 24 months. you can revoke consent at any
                time in the account page or by clearing your cookies.
              </p>
              <p className='text-sm text-muted-foreground'>
                view our{' '}
                <Link
                  to={privacyPolicyUrl}
                  className='text-primary underline hover:text-primary/80 focus-visible:text-primary/70 active:text-primary/70 transition'
                  target='_blank'
                  rel='noopener noreferrer'
                >
                  privacy Policy
                </Link>{' '}
                for more details about how we handle your data.
              </p>
            </div>
          )}
        </div>
      </div>

      <div className='flex justify-end gap-3 pt-6'>
        <Button onClick={handleDeclineAll}>reject all</Button>
        <Button onClick={handleSavePreferences}>save preferences</Button>
      </div>
    </div>
  );

  if (!showConsent) return null;

  // Show sheet on mobile, dialog on desktop
  const PreferencesDialog = (
    <Dialog open={showPreferences} onOpenChange={setShowPreferences}>
      <DialogContent
        className={cn(
          'max-w-[95%] max-h-screen overflow-auto rounded-lg sm:max-w-lg',
          showDetails && 'max-h-[438px]'
        )}
      >
        <DialogHeader>
          <DialogTitle>cookie preferences</DialogTitle>
          <DialogDescription>
            choose which cookies you allow {companyName} to use.
          </DialogDescription>
        </DialogHeader>
        <PreferenceContent />
      </DialogContent>
    </Dialog>
  );

  return (
    <>
      {/* Minimal Banner */}
      <div className='fixed bottom-0 left-0 right-0 border-t bg-background p-4 shadow-lg z-50'>
        <div className='mx-auto flex max-w-7xl flex-col gap-4 sm:flex-row sm:items-center sm:justify-between'>
          <p className='text-sm text-muted-foreground'>
            we use cookies (yummy) to enhance your experience and improve our
            services.{' '}
            <Button
              variant='link'
              className='text-sm text-muted-foreground hover:text-muted-foreground/80 underline h-auto p-0'
              onClick={() => setShowPreferences(true)}
            >
              manage preferences
            </Button>
          </p>
          <div className='flex gap-3'>
            <Button onClick={handleDeclineAll}>reject all</Button>
            <Button onClick={handleAcceptAll}>accept all</Button>
          </div>
        </div>
      </div>

      {/* Preferences Dialog/Sheet */}
      {PreferencesDialog}
    </>
  );
};
