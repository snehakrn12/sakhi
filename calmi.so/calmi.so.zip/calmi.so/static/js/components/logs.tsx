import { Info, Loader2 } from 'lucide-react';
import { useRef } from 'react';
import { Link } from 'react-router-dom';
import { Button } from './ui/button';
import { Skeleton } from './ui/skeleton';

export interface MessageHistoryProps {
  messageHistory: {
    role: 'user' | 'ai';
    message: string;
  }[];
  loading: boolean;
}

export const MessageHistory = ({
  messageHistory,
  loading,
}: MessageHistoryProps) => {
  // const logLines = logs.map((log, index) => <p key={index}>{log.message}</p>);
  const logContainerRef = useRef<HTMLDivElement>(null);

  // useEffect(() => {
  //   if (logContainerRef.current) {
  //     logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
  //   }
  // }, [logLines]);

  return (
    <div className='w-full text-sm'>
      <div ref={logContainerRef} className='relative bg-white grid gap-2'>
        {loading ? (
          <>
            <div className='grid gap-2 content-start'>
              <Skeleton className='w-full max-w-[90%] h-12 rounded-md justify-self-end' />
              <Skeleton className='w-full max-w-[90%] h-16 rounded-md' />
              <Skeleton className='w-full max-w-[60%] h-8 rounded-md justify-self-end' />
              <Skeleton className='w-full max-w-[90%] h-16 rounded-md' />
              <Skeleton className='w-full max-w-[70%] h-20 rounded-md justify-self-end' />
              <Skeleton className='w-full max-w-[90%] h-20 rounded-md' />
              <Skeleton className='w-full max-w-[90%] h-40 rounded-md justify-self-end' />
              <Skeleton className='w-full max-w-[90%] h-12 rounded-md' />
            </div>

            <div className='absolute top-56 mx-auto w-full flex flex-col items-center justify-start gap-1'>
              <Loader2 className='h-4 w-4 animate-spin' />
              <p>loading previous conversations...</p>
            </div>
          </>
        ) : messageHistory.length === 0 ? (
          <div className='p-3 grid gap-2 justify-items-center text-sm bg-gray-100 rounded-xl font-medium text-center'>
            <Info className='w-5 h-5' />
            <p>
              ayy looks like we're starting fresh here - the chat's empty! start
              a session to fill it up
            </p>

            <Button
              className='mt-4 max-w-min'
              asChild
              size='sm'
              variant='primary'
            >
              <Link to='/'>begin first session</Link>
            </Button>
          </div>
        ) : (
          <>
            {messageHistory.map((line, index) => (
              <div
                key={index}
                className={`max-w-[90%] lowercase ${
                  line.role === 'user'
                    ? 'justify-self-end text-right'
                    : 'justify-self-start text-left'
                }`}
              >
                <span
                  className={`inline-block p-2 rounded-lg ${
                    line.role === 'user' ? 'bg-zinc-200' : 'bg-zinc-100'
                  }`}
                >
                  {line.message}
                </span>
              </div>
            ))}
          </>
        )}

        {/* <TextChat
          className='mt-4 mb-2'
          disabled={disabled || loading}
          handleSendMessage={handleSendMessage}
          inputRef={inputRef}
        /> */}
      </div>
    </div>
  );
};
