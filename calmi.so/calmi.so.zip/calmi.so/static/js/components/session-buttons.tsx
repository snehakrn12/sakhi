import { Volume2, VolumeOff, XIcon } from 'lucide-react';
import { useState } from 'react';
import { ConfirmDialog } from './confirm-dialog';
import { SessionSpeakButton } from './session-speak-button';
import { Button } from './ui/button';

interface SessionButtonsProps {
  isRecording: boolean;
  isSpeaking: boolean;
  isMuted: boolean;
  disabled: boolean;
  startRecording: () => void;
  stopRecording: (options?: { graceful?: boolean }) => void;
  handleSpeakButtonToggle: () => void;
  toggleMute: () => void;
}

export const SessionButtons = ({
  isRecording,
  isSpeaking,
  isMuted,
  disabled,
  startRecording,
  stopRecording,
  handleSpeakButtonToggle,
  toggleMute,
}: SessionButtonsProps) => {
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);

  const confirmEndSession = () => {
    setIsConfirmDialogOpen(true);
  };

  return (
    <div className='flex justify-center'>
      <ConfirmDialog
        handleConfirm={() => stopRecording({ graceful: false })}
        headline='want to end the session?'
        description='no worries you can continue anytime'
        open={isConfirmDialogOpen}
        onOpenChange={setIsConfirmDialogOpen}
      />

      {!isRecording ? (
        <div className='relative'>
          <Button size='lg' variant='primary' onClick={startRecording}>
            begin session
          </Button>
        </div>
      ) : (
        <div className='flex items-center justify-center gap-16'>
          <Button
            rounded='full'
            variant='secondary'
            size='icon'
            onClick={() => toggleMute()}
            title='mute/unmute'
          >
            {isMuted ? (
              <VolumeOff size={24} className='text-[#1E1E1E]' />
            ) : (
              <Volume2 size={24} className='text-[#1E1E1E]' />
            )}
          </Button>

          <SessionSpeakButton
            handleSpeakButtonToggle={handleSpeakButtonToggle}
            disabled={disabled}
            isSpeaking={isSpeaking}
          />

          <Button
            rounded='full'
            variant='secondary'
            size='icon'
            onClick={confirmEndSession}
            title='end session'
          >
            <XIcon size={24} className='text-[#1E1E1E]' />
          </Button>
        </div>
      )}
    </div>
  );
};
