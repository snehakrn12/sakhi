import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className='grid px-4 sm:px-8 md:px-12 lg:px-16 xl:px-20 max-w-7xl mx-auto'>
      <div className='grid grid-cols-3 gap-4 gap-y-8 justify-between items-start border-t border-t-zinc-200 py-12 sm:justify-start sm:gap-x-16 md:grid-cols-4 md:gap-0'>
        <div className='flex gap-1 items-center text-xl font-semibold text-black leading-none'>
          <div className='w-5 h-5 rounded-full bg-accent-default'></div>
          <Link title='calmi homepage' to='/' className='mb-[2px]'>
            calmi
          </Link>
        </div>

        <div className='grid gap-2 text-zinc-600 font-normal'>
          <p className='text-xl font-semibold text-black leading-none'>
            socials
          </p>
          <a
            href='https://www.instagram.com/ddennishan'
            target='_blank'
            rel='noopener noreferrer'
          >
            instagram
          </a>
          <a
            href='https://www.tiktok.com/@adennishan'
            target='_blank'
            rel='noopener noreferrer'
          >
            tiktok
          </a>
          <a
            href='https://x.com/aDennisHan'
            target='_blank'
            rel='noopener noreferrer'
          >
            x (twitter)
          </a>
          <a
            href='https://www.linkedin.com/in/dennishanaydin'
            target='_blank'
            rel='noopener noreferrer'
          >
            linkedin
          </a>
        </div>

        <div className='grid gap-2 text-zinc-600 font-normal'>
          <p className='text-xl font-semibold text-black leading-none'>legal</p>
          <Link to='/privacy-policy' target='_blank' rel='noopener noreferrer'>
            privacy policy
          </Link>
          <Link
            to='/terms-of-service'
            target='_blank'
            rel='noopener noreferrer'
          >
            terms of service
          </Link>
          <Link to='/ai-disclaimer' target='_blank' rel='noopener noreferrer'>
            ai disclaimer
          </Link>
        </div>

        <p className='text-sm col-span-3 justify-self-center font-semibold text-center md:col-start-4 md:justify-self-end md:max-w-[180px] md:text-right'>
          <span className='inline-block'>© 2024 Calmi Inc</span>{' '}
          <span className='inline-block'>by dennis han & vlady nyz</span>
        </p>
      </div>
    </footer>
  );
}
