import { Check } from 'lucide-react';
import { Feature } from '../types';
import VideoPlayer from './video-player';

interface FeatureCardProps {
  feature: Feature;
}

export const FeatureCard = ({ feature }: FeatureCardProps) => {
  return (
    <article className='group grid gap-5 p-4 bg-[#f4f4f4] rounded-2xl md:grid-cols-[1fr,1fr] md:p-5 2xl:p-8 2xl:gap-8'>
      <div className='md:group-even:order-1'>
        <div className='grid gap-1 md:flex md:flex-col'>
          <h4 className='font-semibold text-xl lg:text-2xl 2xl:text-[28px]'>
            {feature.title}
          </h4>
          <p className='max-w-[440px] font-semibold 2xl:text-lg'>
            {feature.description}
          </p>
        </div>

        <ul className='text-sm mt-4 2xl:mt-6 2xl:text-base'>
          {feature.bulletPoints.map((point, index) => (
            <li key={index} className='flex gap-1 items-center'>
              <Check className='w-4 2xl:w-5' />
              <p>{point}</p>
            </li>
          ))}
        </ul>
      </div>

      <VideoPlayer
        videoSources={[
          {
            src: feature.mediaSrc,
            type: 'video/mp4',
          },
        ]}
        posterImage='/images/intro-poster.webp'
        autoplay
        muted
        loop
        className='rounded-2xl'
      />
    </article>
  );
};
