import { useEffect, useRef, useState } from 'react';
import { cn } from '../utils';

interface AnimatedMessageProps {
  message: string;
  typingSpeed?: number;
  typingDelay?: number;
}

export const AnimatedMessage = ({
  message,
  typingDelay = 500,
  typingSpeed = 60,
}: AnimatedMessageProps) => {
  const [displayedMessage, setDisplayedMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showFade, setShowFade] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Remove any 'undefined' from the message
    const cleanMessage = message.replace(/undefined/g, '').trim();

    if (cleanMessage.length === 0) {
      setDisplayedMessage('');
      setIsTyping(false);
      return;
    }

    setDisplayedMessage('');
    setIsTyping(false);

    // Add a 2-second delay before starting the typing animation
    const startDelay = setTimeout(() => {
      setIsTyping(true);
      let index = 0;

      const typingInterval = setInterval(() => {
        if (index < cleanMessage.length) {
          setDisplayedMessage((prev) => cleanMessage.slice(0, prev.length + 1));
          index++;

          // Scroll to the bottom of the container
          if (containerRef.current) {
            containerRef.current.scrollTop = containerRef.current.scrollHeight;
            const isOverflowing =
              containerRef.current.scrollHeight >
              containerRef.current.clientHeight;
            setShowFade(isOverflowing);
          }
        } else {
          clearInterval(typingInterval);
          setIsTyping(false);
        }
      }, typingSpeed);

      return () => clearInterval(typingInterval);
    }, typingDelay);

    return () => clearTimeout(startDelay);
  }, [message, typingSpeed, typingDelay]);

  return (
    <div className='relative'>
      <div
        ref={containerRef}
        className={cn(
          'transition-opacity duration-500 lowercase font-medium h-[60px] leading-[1.3] overflow-hidden scroll-smooth',
          isTyping ? 'opacity-100' : 'opacity-80'
        )}
      >
        {displayedMessage.split('\n').map((line, index, array) => (
          <div key={index}>
            {line}
            {index === array.length - 1 && isTyping && <span>|</span>}
          </div>
        ))}
      </div>

      <div
        className={cn(
          'absolute inset-y-0 left-0 h-6 w-44 bg-gradient-to-r from-white to-transparent pointer-events-none transition-opacity duration-300 ease-in-out',
          showFade ? 'opacity-100' : 'opacity-0'
        )}
      ></div>
    </div>
  );
};
