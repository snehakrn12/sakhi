import { Info, Mic, VolumeOff, XIcon } from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Label } from './ui/label';
import { Switch } from './ui/switch';

const DemoButton = ({ children, ...props }: React.ComponentProps<'div'>) => (
  <div
    role='presentation'
    aria-hidden='true'
    className='w-full h-28 flex items-center justify-center bg-zinc-100 rounded-lg'
    {...props}
  >
    {children}
  </div>
);

export const SessionInfoDialog = () => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          onClick={() => setOpen(true)}
          className='fixed bottom-4 right-4 p-1 z-50'
          variant='icon'
          aria-label='open session information'
        >
          <Info className='w-6' />
        </Button>
      </DialogTrigger>

      <DialogContent
        overlayClassName='bg-black/20'
        className='max-w-[95%] gap-0 sm:max-w-[448px] p-4 pb-8 mx-auto rounded-lg [&>button]:hidden'
      >
        <DialogHeader className='flex flex-row justify-between items-center border-b border-zinc-400 pb-4'>
          <DialogTitle className='text-2xl font-semibold'>
            quick guide
          </DialogTitle>
          <DialogDescription className='sr-only'>
            guide to session controls and duration information
          </DialogDescription>

          <Button
            onClick={() => setOpen(false)}
            className='p-1 m-0'
            variant='icon'
            aria-label='close dialog'
          >
            <XIcon className='w-6' />
          </Button>
        </DialogHeader>

        <div
          className='grid gap-6 pt-5 max-h-[500px] overflow-y-auto'
          role='document'
          aria-label='session controls guide'
        >
          <section>
            <h2 className='text-lg font-semibold'>let's talk duration</h2>
            <div className='p-3 bg-zinc-100 rounded-lg mt-1'>
              <h3 className='font-semibold'>max duration</h3>
              <ul className='list-disc'>
                <li className='ml-6 grid grid-cols-[40px,1fr] gap-2'>
                  <span className='font-semibold'>free:</span>
                  <span>10 min</span>
                </li>
                <li className='ml-6 grid grid-cols-[40px,1fr] gap-2'>
                  <span className='font-semibold'>plus:</span>
                  <span>20 min</span>
                </li>
                <li className='ml-6 grid grid-cols-[40px,1fr] gap-2'>
                  <span className='font-semibold'>pro:</span>
                  <span>30 min</span>
                </li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className='text-lg font-semibold'>what to press</h2>
            <div className='grid gap-3 mt-1'>
              <div className='grid grid-cols-2 gap-3'>
                <DemoButton>
                  <div className='flex items-center gap-2 justify-end h-12'>
                    <Label className='pointer-events-none'>gen z mode</Label>
                    <Switch
                      disabled
                      aria-disabled='true'
                      id='gen-z-mode'
                      checked
                    />
                  </div>
                </DemoButton>
                <p>
                  gen z mode toggle.
                  <br />
                  calmi, but chill.
                </p>
              </div>

              <div className='grid grid-cols-2 gap-3'>
                <DemoButton>
                  <Button
                    size='md'
                    variant='primary'
                    className='pointer-events-none'
                    aria-disabled='true'
                    tabIndex={-1}
                  >
                    begin session
                  </Button>
                </DemoButton>
                <p>
                  begin session
                  <br />
                  pretty self-explanatory.
                </p>
              </div>

              <div className='grid grid-cols-2 gap-3'>
                <DemoButton>
                  <Button
                    rounded='full'
                    variant='secondary'
                    className='bg-zinc-200 pointer-events-none'
                    size='icon'
                    aria-disabled='true'
                    tabIndex={-1}
                  >
                    <Mic size={24} className='text-[#1E1E1E]' />
                  </Button>
                </DemoButton>
                <p>
                  start speaking.
                  <br />
                  tap to talk.
                </p>
              </div>

              <div className='grid grid-cols-2 gap-3'>
                <DemoButton>
                  <Button
                    rounded='full'
                    variant='secondary'
                    className='bg-zinc-200 pointer-events-none'
                    size='icon'
                    aria-disabled='true'
                    tabIndex={-1}
                  >
                    <div className='w-[22px] aspect-square bg-zinc-500 rounded-md' />
                  </Button>
                </DemoButton>
                <p>
                  stop speaking.
                  <br />
                  tap when you’re done—calmi will respond.
                </p>
              </div>

              <div className='grid grid-cols-2 gap-3'>
                <DemoButton>
                  <Button
                    rounded='full'
                    variant='secondary'
                    className='bg-zinc-200 pointer-events-none'
                    size='icon'
                    aria-disabled='true'
                    tabIndex={-1}
                  >
                    <XIcon size={24} className='text-[#1E1E1E]' />
                  </Button>
                </DemoButton>
                <p>
                  end session.
                  <br />
                  wrap it up.
                </p>
              </div>

              <div className='grid grid-cols-2 gap-3'>
                <DemoButton>
                  <Button
                    rounded='full'
                    variant='secondary'
                    className='bg-zinc-200 pointer-events-none'
                    size='icon'
                    aria-disabled='true'
                    tabIndex={-1}
                  >
                    <VolumeOff size={24} className='text-[#1E1E1E]' />
                  </Button>
                </DemoButton>
                <p>
                  mute calmi.
                  <br />
                  shhhh.
                </p>
              </div>
            </div>
          </section>

          <DialogFooter className='pt-6 pb-4'>
            <Button
              className='w-full'
              variant='outline'
              onClick={() => setOpen(false)}
            >
              close
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
};
