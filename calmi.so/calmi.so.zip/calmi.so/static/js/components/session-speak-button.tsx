import { Loader2, Mic } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Button } from './ui/button';

interface SessionSpeakButtonProps {
  isSpeaking: boolean;
  disabled: boolean;
  handleSpeakButtonToggle: () => void;
}

export const SessionSpeakButton = ({
  isSpeaking,
  disabled,
  handleSpeakButtonToggle,
}: SessionSpeakButtonProps) => {
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    setIsAnimating(true);
    const timer = setTimeout(() => setIsAnimating(false), 300);
    return () => clearTimeout(timer);
  }, [isSpeaking]);

  return (
    <Button
      variant='primary'
      size='icon'
      iconSize='lg'
      onClick={() => handleSpeakButtonToggle()}
      rounded='full'
      disabled={disabled}
      title='start/stop speaking'
      className={`group relative w-16 h-16  border-2 border-accent-default hover:border-accent-hover focus-visible:border-accent-active active:border-accent-active ${
        isSpeaking
          ? 'bg-white hover:bg-white focus-visible:bg-white active:bg-white'
          : 'bg-accent-default hover:bg-accent-hover focus-visible:bg-accent-active active:bg-accent-active'
      }`}
    >
      {disabled ? (
        <Loader2 className='h-8 w-8 animate-spin' />
      ) : (
        <>
          <Mic
            size={32}
            className={`text-[#1E1E1E] absolute inset-0 z-[2] m-auto transition-all duration-200 ${
              isSpeaking ? 'scale-0 opacity-0' : 'scale-100 opacity-100'
            }`}
          />
          <div
            className={`absolute inset-0 bg-accent-default transition-all duration-200 rounded-full ${
              isSpeaking
                ? 'scale-0'
                : 'scale-100 group-hover:bg-accent-hover group-active:bg-accent-active group-focus-visible:bg-accent-active'
            } ${isAnimating ? 'animate-pulse' : ''}
              `}
          />
          <div
            className={`absolute inset-0 bg-accent-default transition-all duration-200 rounded-lg group-hover:bg-accent-hover group-active:bg-accent-active group-focus-visible:bg-accent-active ${
              isSpeaking ? 'scale-[0.4]' : 'scale-0'
            } ${isAnimating ? 'animate-pulse' : ''}`}
          />
        </>
      )}
    </Button>
  );
};
