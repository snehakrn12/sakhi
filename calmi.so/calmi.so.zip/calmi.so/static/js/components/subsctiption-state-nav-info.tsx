import { Info } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SubscriptionPlan } from '../types';
import { Badge, Button, Progress } from './';

export const SubscriptionStateNavInfo = ({
  subscriptionPlan,
  sessionCount,
  sessionCountLimit,
  sessionCountLimitReached,
  isSubscribed,
}: {
  subscriptionPlan: SubscriptionPlan;
  sessionCount: number;
  sessionCountLimit: number;
  sessionCountLimitReached: boolean;
  isSubscribed: boolean;
}) => {
  return (
    <div>
      <div className='mt-auto py-4 grid gap-1 border-t text-black'>
        <div className='grid gap-2 rounded-xl px-2'>
          <div className='flex items-center justify-between font-sans text-sm'>
            <Badge className='bg-zinc-100 text-black text-sm rounded-lg py-0 px-2'>
              {!subscriptionPlan ? 'free' : subscriptionPlan}
            </Badge>
            <p>
              {sessionCount}/{sessionCountLimit} sessions
            </p>
          </div>
          <Progress value={(sessionCount / sessionCountLimit) * 100} />

          {sessionCountLimitReached && (
            <div className='grid grid-cols-[auto,1fr] items-center gap-2 border rounded-md mt-2 py-1 px-2'>
              <Info className='w-4 h-4' />
              <p className='font-semibold text-sm'>
                {subscriptionPlan === 'plus' || subscriptionPlan === 'pro'
                  ? 'monthly limit reached.'
                  : 'monthly limit reached. upgrade for more.'}
              </p>
            </div>
          )}
        </div>

        {(!isSubscribed || subscriptionPlan === 'plus') && (
          <Button asChild size='sm' variant='primary' className='mt-2 mx-2'>
            <Link to='/pricing'>
              <span>
                {subscriptionPlan === 'plus' ? 'view plans' : 'upgrade'}
              </span>
            </Link>
          </Button>
        )}
      </div>
    </div>
  );
};
