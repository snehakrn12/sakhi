import { Session } from '@supabase/supabase-js';
import { Home, NotebookText, User } from 'lucide-react';
import * as React from 'react';
import { SubscriptionPlan } from '../types';
import { CalmiLogo } from './calmi-logo';
import { NavFooter } from './nav-footer';
import { NavMain } from './nav-main';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarRail,
} from './ui/sidebar';

// This is sample data.
const data = {
  navMain: [
    {
      title: 'home',
      url: '/',
      icon: Home,
      isActive: true,
    },
    {
      title: 'account',
      url: '/account',
      icon: User,
    },
    {
      title: 'therapy profile',
      url: '/profile',
      icon: NotebookText,
      items: [
        {
          title: 'overview',
          url: '/profile',
        },
        {
          title: 'history',
          url: '/profile?tab=history',
        },
      ],
    },
  ],
};

export function AppSidebar({
  currentPathname,
  session,
  isSubscribed,
  sessionCountLimitReached,
  sessionCount,
  subscriptionPlan,
  handleLogout,
  ...props
}: {
  currentPathname: string;
  session: Session | null;
  isSubscribed: boolean;
  sessionCountLimitReached: boolean;
  sessionCount: number;
  subscriptionPlan: SubscriptionPlan;
  handleLogout: () => void;
} & React.ComponentProps<typeof Sidebar>) {
  return (
    <Sidebar {...props}>
      <SidebarHeader className='pt-5'>
        <SidebarMenu>
          <SidebarMenuItem>
            <CalmiLogo variant='small' className='pl-2' />
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent>
        <NavMain items={data.navMain} />
      </SidebarContent>
      <SidebarFooter>
        <NavFooter
          isSubscribed={isSubscribed}
          sessionCountLimitReached={sessionCountLimitReached}
          sessionCount={sessionCount}
          handleLogout={handleLogout}
          subscriptionPlan={subscriptionPlan}
        />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
