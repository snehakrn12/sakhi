import { createClient } from '@supabase/supabase-js';
import { Database } from './types';

const supabaseUrl = 'https://dpzmxwxakyjxcdweayts.supabase.co';
const supabaseKey =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRwem14d3hha3lqeGNkd2VheXRzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTcyMjkxMTA1MiwiZXhwIjoyMDM4NDg3MDUyfQ.HJTj60AEOZvWFPGIVcC6LXYoh0O0NeB67d7AugeyvVw';

export const supabase = createClient<Database>(supabaseUrl, supabaseKey);
