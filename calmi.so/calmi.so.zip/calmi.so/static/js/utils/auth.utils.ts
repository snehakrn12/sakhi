import { AUTH_ERROR_MESSAGES } from '../constants';
import { supabase } from '../supabaseClient';

interface ResetTokenResponse {
  isValid: boolean;
  error?: string;
}

export const validatePassword = (
  password: string
): { isValid: boolean; error: string } => {
  const minLength = 8;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumbers = /\d/.test(password);
  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

  if (password.length > 72) {
    return {
      isValid: false,
      error: 'Password exceeds maxmium length of 72 characters',
    };
  }

  if (password.length < minLength) {
    return {
      isValid: false,
      error: 'Password must be at least 8 characters long',
    };
  }

  if (!hasUpperCase || !hasLowerCase) {
    return {
      isValid: false,
      error: 'Password must contain both upper and lowercase letters',
    };
  }

  if (!hasNumbers) {
    return {
      isValid: false,
      error: 'Password must contain at least one number',
    };
  }
  if (!hasSpecialChar) {
    return {
      isValid: false,
      error: 'Password must contain at least one special character',
    };
  }

  return { isValid: true, error: '' };
};

export const sanitizeErrorMessage = (error: string): string => {
  const sanitizedMessage =
    Object.entries(AUTH_ERROR_MESSAGES).find(([key]) =>
      error.toLowerCase().includes(key.toLowerCase())
    )?.[1] || AUTH_ERROR_MESSAGES.default;

  return sanitizedMessage;
};

export const validateResetToken = async (
  token: string
): Promise<ResetTokenResponse> => {
  try {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(token);

    if (error || !user) {
      return { isValid: false, error: 'Invalid or expired reset token' };
    }

    // Check if token is within expiry window (24 hours)
    const tokenTimestamp = user.confirmation_sent_at;
    if (
      !tokenTimestamp ||
      Date.now() - new Date(tokenTimestamp).getTime() > 24 * 60 * 60 * 1000
    ) {
      return { isValid: false, error: 'Reset token has expired' };
    }

    return { isValid: true };
  } catch (error) {
    return { isValid: false, error: 'Invalid reset token' };
  }
};
