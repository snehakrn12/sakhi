import axios from 'axios';
import EventEmitter from 'events';
import {
  AUDIO_CONTEXT_SETTINGS,
  END_OF_SPEECH_TOKEN,
  FREE_SESSION_DURATION_LIMIT,
  INTERRUPTED_MESSAGE,
  PLUS_SESSION_DURATION_LIMIT,
  PRO_SESSION_DURATION_LIMIT,
} from '../constants';
import { supabase } from '../supabaseClient';
import { SubscriptionPlan } from '../types';

export class Streamer extends EventEmitter {
  ws: WebSocket;
  stream: MediaStream | null = null;
  processor: ScriptProcessorNode | null = null;
  audioContext: AudioContext | null = null;
  userIsSpeaking: boolean = false;
  currentLogMessage: string | null = null;
  hasError: boolean = false;

  constructor(ws: WebSocket, private logMessage: (...args: any[]) => void) {
    super();
    this.ws = ws;
    this.audioContext = new AudioContext(AUDIO_CONTEXT_SETTINGS);
  }

  async start() {
    try {
      const constraints = { audio: true };
      this.stream = await navigator.mediaDevices.getUserMedia(constraints);
      const source = this.audioContext!.createMediaStreamSource(this.stream);
      this.processor = this.audioContext!.createScriptProcessor(1024, 1, 1);
      this.processor.onaudioprocess = (event) => {
        if (
          this.ws.readyState === WebSocket.OPEN &&
          this.userIsSpeaking &&
          !this.hasError
        ) {
          this.ws.send(event.inputBuffer.getChannelData(0));
        }
      };
      source.connect(this.processor);
      this.processor.connect(this.audioContext!.destination);
      return true;
    } catch (error) {
      if (error instanceof DOMException && error.name === 'NotAllowedError') {
        this.emit('microphoneDenied');
      }
      throw error;
    }
  }

  startSpeech() {
    this.hasError = false;
    this.userIsSpeaking = true;
    this.emit('speechStart');
    this.logMessage('listening...');
    this.currentLogMessage = 'listening...';
  }

  endSpeech() {
    this.userIsSpeaking = false;
    this.emit('speechEnd');
    this.logMessage('thinking...');
    this.currentLogMessage = 'thinking...';
    this.ws.send(END_OF_SPEECH_TOKEN);
  }

  async stop(graceful: boolean = false) {
    this.audioContext?.suspend();
    this.stream?.getTracks().forEach((track) => {
      track.stop();
      this.stream?.removeTrack(track);
    });
    this.processor && (this.processor.onaudioprocess = null);
  }

  handleError() {
    this.userIsSpeaking = false;
    this.hasError = true;
    if (!this.listenerCount('error')) {
      this.on('error', () => {
        // Silent handler to prevent unhandled error
      });
    }
    this.emit('error');
    setTimeout(() => {
      this.hasError = false;
    }, 100);
  }
}

export class Playback extends EventEmitter {
  samples: Float32Array[] = [];
  lastFramePlayed: 'silence' | 'non-silence' = 'silence';
  analyser: AnalyserNode | null = null;
  gainNode: GainNode;
  isMuted: boolean = false;

  constructor(
    public audioContext: AudioContext,
    initialMuteState: boolean = false
  ) {
    super();
    this.audioContext.suspend();
    const scriptNode = this.audioContext.createScriptProcessor(1024, 1, 1);

    // Create an analyser node
    this.analyser = this.audioContext.createAnalyser();
    this.analyser.fftSize = 256;

    // Create a gain node
    this.gainNode = this.audioContext.createGain();
    this.isMuted = initialMuteState;
    this.updateGainValue();

    scriptNode.onaudioprocess = (event) => {
      if (this.samples.length > 0) {
        if (this.lastFramePlayed === 'silence') {
          this.emit('playbackStart');
        }
        this.lastFramePlayed = 'non-silence';
        event.outputBuffer.getChannelData(0).set(this.samples[0]);
        this.samples.shift();
      } else {
        if (this.lastFramePlayed === 'non-silence') {
          this.emit('playbackEnd');
        }
        this.lastFramePlayed = 'silence';
        const silence = new Float32Array(1024);
        event.outputBuffer.getChannelData(0).set(silence);
      }
    };

    scriptNode.connect(this.analyser);
    this.analyser.connect(this.gainNode);
    this.gainNode.connect(this.audioContext.destination);
  }

  updateGainValue() {
    if (this.gainNode) {
      this.gainNode.gain.setValueAtTime(
        this.isMuted ? 0 : 1,
        this.audioContext.currentTime
      );
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    this.updateGainValue();
  }

  // ... (rest of the Playback class methods)
  async clear() {
    await this.audioContext.suspend();
    const dirty = this.samples.length > 0;
    this.samples = [];
    await this.audioContext.resume();
    this.emit('clear', { dirty });
    this.lastFramePlayed = 'silence';
    return dirty;
  }

  start() {
    this.audioContext.resume();
  }

  stop(graceful: boolean = false) {
    if (graceful) {
      if (this.samples.length > 0) {
        return setTimeout(() => {
          this.stop(true);
        }, 1000);
      }
    } else {
      this.audioContext.suspend();
    }
  }

  addSamples(samples: Float32Array) {
    this.samples.push(samples);
  }
}

export const generateSessionSummary = async (
  sessionId: string,
  token: string
) => {
  try {
    await axios.post(
      `${process.env.REACT_APP_API_URL}/session-summary`,
      {
        sessionId,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
  } catch (error) {}
};

export const saveMessageToMessageHistory = async (
  userId: string,
  sessionId: string,
  message: string
) => {
  if (message === INTERRUPTED_MESSAGE) return;

  const role = message.startsWith('assistant') ? 'ai' : 'user';
  const messageWithoutRole = message.replace(/(assistant: |user: )/, '');

  await supabase.from('message_history').insert({
    session_id: sessionId,
    user_id: userId,
    message: messageWithoutRole,
    role,
  });
};

export const generateTherapyProfile = async (sessionId: string) => {
  const { data, error } = await supabase.auth.getSession();

  if (error || !data.session) {
    return;
  }

  const token = data.session.access_token;

  try {
    await axios.post(
      `${process.env.REACT_APP_API_URL}/therapy-profile`,
      {
        sessionId,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
  } catch (error) {}
};

export const getSessionDurationLimit = (
  isSubscribed: boolean,
  subscriptionPlan: SubscriptionPlan
) => {
  if (!isSubscribed) return FREE_SESSION_DURATION_LIMIT;

  switch (subscriptionPlan) {
    case 'plus':
      return PLUS_SESSION_DURATION_LIMIT;
    case 'pro':
    case 'unlimited':
      return PRO_SESSION_DURATION_LIMIT;
    default:
      return FREE_SESSION_DURATION_LIMIT;
  }
};
